<!DOCTYPE html>
<html lang="en">

<head>
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <!--- Basic Page Needs  -->
    <meta charset="utf-8">
    <title>Motlee SME Cloud </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="Description" CONTENT="Career Development platform for Hospitailty">	
    <!-- Mobile Specific Meta  -->
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
	<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/style.css">
			
			<link rel="stylesheet" type="text/css" media="screen and (max-width: 360px)" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen and (min-width: 361px) and (max-width: 480px)" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen and (min-width: 481px)" href="css/style.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

	
</head>

<body  style="background-image: url('img/demo-thumb/bg-01.jpg');">

    <!-- prealoader area start -->
      <!--<div id="preloader">
        <div class="spiner"></div>
		<div class="logo"></div> -->
    </div>
    <!-- prealoader area end -->
    <!-- Crumbs area start -->
   
    <!-- Crumbs area end -->
    <!-- counter-box area start -->
   
    <!-- counter-box area end -->
    <!-- demo area start -->
	
	
    <div class="demo-area" >
        <div class="container">
            <div class="row">
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
							<a href="Kenya/"  target="_blank" style="color: #0033FF " > <img src="img/demo-thumb/kenya.png" alt="demo image"></a>
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="Kenya/" target="_blank" style="color: #0033FF " > <button class="form-control" style="color: #0033FF" >
							Kenya
						</button> </a></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 ">
					
					
                    <div class="demo-item">
                        <div class="thumb-area">
                         <a href="index4.php"  target="_blank" style="color: #0033FF " > <img src="img/demo-thumb/Namibia.png" alt="demo image">	</a>				
                        </div>
                        <div class="demo-title">
                             <h2> <a href="index4.php" target="_blank" style="color: #0033FF " ><button class="form-control" style="color: #0033FF" >
							Namibia
						</button>  </a></h2>
                        </div>
                    </div>
                </div>
				
                
				
			
               
               
               
                
                
            </div>
	</div>


   
    <!-- demo area end -->
<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						
						
				
						
					</div><div align="center">
					<p style="padding: 100px">		
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
	</div>
					
								 </div>
	

				</div>
			</footer>
    <!-- footer area start -->
    
    <!-- footer area end -->

    <!-- Scripts -->
    <script src="js/jquery-3.2.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animatedheadline.js"></script>
    <script src="js/counterup.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/theme.js"></script>
	
	<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>		
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
</body>

</html>