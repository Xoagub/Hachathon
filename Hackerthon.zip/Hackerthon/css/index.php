	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" type="image/x-icon" href="banner.png" />
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Recruitment</title>
<link rel="shortcut icon" type="image/x-icon" href="banner.png" />
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>
		 <?php 
 // Require https
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>

			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index.php"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li><a class="btn" href="../../index.php" style="color:#000000">Home</a>
							   <li style="background-color:#0066FF" ><a class="btn" href="register3.php"  style="font-size: 20px;" style="color:#000000">Register</a>
				           
								</li>
						
				      	         <li  ><a class="btn" href="login1.html" style="color:#000000" >Login</a>
				           
				          </li>    
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->


			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex align-items-center justify-content-center">
						<div class="banner-content col-lg-12">
								
							
													</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start features Area -->
			<section class="features-area">
				<div class="container">
					<div class="row">
						
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Accessibility</h4>
								<p>
									 Our cloud based platform provides 24/7 access.


								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Cost</h4>
								<p>
									Lower recruitment costs for your organisation.
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Efficiency</h4>
								<p>
									Improved efficiency of the recruitment process.
								</p>
							</div>
						</div>	
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Screening </h4>
								<p>
								Screening and checking of skills and qualifications.
								</p>
							</div>
						</div>																	
					</div>
				</div>	
			</section>
			<!-- End features Area -->
			
			<!-- Start popular-post Area -->
			
			<!-- End popular-post Area -->
			
			<!-- Start feature-cat Area -->
			
			<!-- End feature-cat Area -->
			
			<!-- Start post Area -->
			
			<!-- End post Area -->
				

				<section class="banner-area1 relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex align-items-center justify-content-center">
						<div class="banner-content col-lg-12">
								
							
													</div>											
					</div>
				</div>
			</section>
			<?php
			include('coon_we.php');
			
			?>
				<section class="service-area section-gap" id="service">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-40 header-text">
							<h1>Why Choose Us</h1>
							<p>
								We want to link you to the right candidate to grow your business.
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-user"></span>Database of Job Seekers</h4>
								<p>
										Number of Candidates on our System looking for Jobs :<h3><span ></span><?php echo $count ; ?>
								</p></h3>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span ></span> Growing Solution for Recruiters</h4>
								<p>
									Number of Recruiters using our system for Jobs : <h3><span ></span><?php echo $count2 ; ?></p></h3>
							</div>
						</div>
						
										
									
					</div>
				</div>	
			</section>
			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap" id="join">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							<div class="title text-center">
								<h1 class="mb-10 text-white">Join us today without any hesitation</h1>
								<p class="text-white">Contact us so we can come explain how we can disrupt your current recruitment process .</p>
								
								
							</div>
						</div>
					</div>	
				</div>	
			</section>
			<!-- End calto-action Area -->
<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Contact Details </h6>
								<p style="color:#000000" >Mail: hr@motlee-systems.com. <br> Contact number : +264 0816321231 <br> Location : 118 Robert Mugabe Avenue <br> Windhoek Namibia</p>
										
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget mail-chimp">
								<h6 class="mb-30">Key Partners</h6>
								<ul class="instafeed d-flex flex-wrap">
									<li><img src="img/sanlam.png" width="90px" height="80px" alt=""></li>
				   				<li><img src="img/nbii.jpg" width="90px" height="80px"  alt=""></li>
				   				<li><img src="img/NUST.jpg" width="90px" height="80px"  alt=""></li>
									<li><img src="img/dololo_white_man.png" width="95px" height="75px" alt=""></li>
									
									
								
								</ul>
							</div>
						</div>									
					</div>
					<p style="padding-left:350px">		
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
								 </div>
				

				</div>
			</footer>
		
			<!-- End footer Area -->		

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>		
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>



