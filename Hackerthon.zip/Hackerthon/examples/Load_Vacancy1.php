
 <?php
	  
$company44 = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Past_Work"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Company=$_POST["Company"]; 
$Position=$_POST["Position"];
$Number_Vacancies=$_POST["Number_Vacancies"];

$Job_Grade=$_POST["Job_Grade"]; 
$Level_Operation=$_POST["Level_Operation"];
$New_Old_Position=$_POST["New_Old_Position"];

$Contact_Person=$_POST["Contact_Person"]; 
$Contact_Details=$_POST["Contact_Details"];
$Years_Experince=$_POST["Years_Experince"];

$Qualifications=$_POST["Qualifications"]; 
$Skills=$_POST["Skills"];
$Job_Description=$_POST["Job_Description"];

$Role_Requirement=$_POST["Role_Requirement"]; 
$Closing_Date=$_POST["Closing_Date"];





	$sql="SELECT * FROM $tbll_name WHERE Email='".$company44."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){


$fql=("UPDATE $tbll_name SET Company1 = '".$Company."', Person1 = '".$Person."', Contact1 = '".$Contact."' , Company2 = '".$Company1."', Person2 = '".$Person1."', Contact2 = '".$Contact1."', Company3 = '".$Company2."', Person3 = '".$Person2."', Contact3 = '".$Contact2."', Company4 = '".$Company3."', Person4 = '".$Person3."', Contact4 = '".$Contact3."', Company5 = '".$Company4."', Person5= '".$Person4."', Contact5 = '".$Contact4."' WHERE Email = '".$company44."' ");


	
if (!mysqli_query($link,$fql))
  {  

  header("location: reference.php");

  }

header("location: reference.php");
	
	}
	else
	{
		
	$kql="INSERT INTO $tbll_name (Email, Company1, Person1, Contact1, Company2, Person2, Contact2, Company3, Person3, Contact3, Company4, Person4, Contact4, Company5, Person5, Contact5)
VALUES
( '$company44','$Company', '$Person', '$Contact', '$Company1', '$Person1', '$Contact1', '$Company2', '$Person2', '$Contact2', '$Company3', '$Person3', '$Contact3', '$Company4', '$Person4', '$Contact4')";

if (!mysqli_query($link,$kql))
  {
  die('Error: ' . mysqli_error($link));
  }
 
	header("location: reference.php");
	
	}
	
	  ?>
 



