
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Name1=$_POST["Name"]; 
$Surname1=$_POST["Surname"];
$email1=$_POST["email"]; 
$Cellphone1=$_POST["Cellphone"];
$Gender1=$_POST["Gender"]; 
$Age1=$_POST["Age"];
$Address1=$_POST["Address"]; 
$City1=$_POST["City"];
$Po1=$_POST["Po"]; 
$Country1=$_POST["Country"];
$Q1=$_POST["Q"]; 
$Me1=$_POST["Me"];

$Me1=$_POST["interest"];



$fql=("UPDATE $tbll_name SET Email= '".$email1."', Name = '".$Name1."', Surname = '".$Surname1."', Cellphone = '".$Cellphone1."', Gender = '".$Gender1."', Age = '".$Age1."', Address = '".$Address1."', City = '".$City1."', Country = '".$Country1."', Highest_Q = '".$Q1."', About = '".$Me1."', Postal_Code = '".$Po1."' WHERE Email = '".$company."' ");


	
if (!mysqli_query($link,$fql))
  {
  die('Error: ' . mysqli_error($link);
  }


	
	  include('user_display.php');
	
	  ?>
 


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                <a href="http://www.Motlee-systems.com/Recruitment/" class="simple-text logo-normal">
                  back to website 
                </a>
				 <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="active">
                        <a href="dashboard.php">
                            <i class="now-ui-icons design_app"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                   
                     <li>
                        <a href="Education.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>High school</p>
                        </a>
                    </li>
                     <li>
                        <a href="Tertiary.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Tertiary Education</p>
                        </a>
                    </li>
                     <li>
                        <a href="Employment.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Employment History </p>
                        </a>
                    </li>
                     <li>
                        <a href="skills.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Skills</p>
                        </a>
                    </li>      <li>
                        <a href="reference.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>References</p>
                        </a>
                    </li>
                     <li>
                        <a href="apply.php">
                            <i class="now-ui-icons users_single-02"></i> <p>Vacancies</p>     </a><li>  <li>
                        <a href="log_Off.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">My Profile</h5>
                            </div>
                            <div class="card-body">
                                 <form action="user1.php" method="post">
                                    <div class="row">
                                        <div class="col-md-5 pr-1">
                                            <div class="form-group">
                                                <label>Name </label>
                                                <input type="text" class="form-control"  placeholder="Name" id="Name" name="Name" value="<?php echo $Name ; ?>" >
                                            </div>
                                        </div>
                                        <div class="col-md-3 px-1">
                                            <div class="form-group">
                                                <label>Surname </label>
                                                <input type="text" class="form-control" placeholder="Surname" id="Surname" name="Surname" value="<?php echo $Surname ; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 pl-1">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" placeholder="Email" id="email" name="email" value="<?php echo $Email ; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 pr-1">
                                            <div class="form-group">
                                                <label>Cellphone</label>
                                                <input type="text" class="form-control" placeholder="Cellphone" id="Cellphone" name="Cellphone" value="<?php echo $Cellphone ;?>" >
                                            </div>
                                        </div>
                                        <div class="col-md-6 pl-1">
                                            <div class="form-group">
                                                <label>Gender</label>
                                                <select name="Gender" id="Gender" class="form-control">
 													 <option value="Male">Male</option>
  													<option value="Female">Female</option>
 												</select>
                                                
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Age</label>
                                                <input type="text" name="Age" id="Age" class="form-control" placeholder="Age" value="<?php echo $Age ; ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="Address" id="Address" class="form-control" placeholder="Home Address" value="<?php echo $Address ; ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 pr-1">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" name="City" id="City" class="form-control" placeholder="City" value="<?php echo $City ; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 px-1">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <input type="text" name="Country" id="Country" class="form-control" placeholder="Country" value="<?php echo $Country ; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 pl-1">
                                            <div class="form-group">
                                                <label>Postal Code</label>
                                                <input type="number" name="Po" id="Po" class="form-control" placeholder="ZIP Code" value="<?php echo $Postal_Code ; ?>">
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Highest Qualification</label>
                                                <textarea rows="4" name="Q" id="Q" cols="80" class="form-control" placeholder="Qualifications" ><?php echo $Highest_Q; ?>  </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>About Me</label>
                                                <textarea name="Me" id="Me" rows="4" cols="80" class="form-control" placeholder="Here can be your description" ><?php echo $About ;?> </textarea>
                                            </div>
                                        </div>
                                    </div>
					 <div class="row">
                                        <div class="col-md-5 pr-1">
                                            <div class="form-group">
                                                 <input type="submit" class="form-control" value="Save Profile" >
                                            </div>
                                        </div>
                              		</div>
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
