

<?php 

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
  $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbl_name="User_Profile"; // Table name 

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query

$sql = "SELECT * FROM $tbl_name  ";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   	$Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country3 = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$dog = $row["English"];
		$Permit = $row["Permit"];

	
		$encrypted_txt1 = encrypt_decrypt('encrypt',  $Name);
		$encrypted_txt2 = encrypt_decrypt('encrypt', $Surname);
		$encrypted_txt3 = encrypt_decrypt('encrypt', $Cellphone);
		$encrypted_txt4 = encrypt_decrypt('encrypt', $Gender);
		$encrypted_txt5 = encrypt_decrypt('encrypt', $Age);
		$encrypted_txt6 = encrypt_decrypt('encrypt', $Address);
		$encrypted_txt7 = encrypt_decrypt('encrypt', $City);
		$encrypted_txt8 = encrypt_decrypt('encrypt', $Country3);
		$encrypted_txt9 = encrypt_decrypt('encrypt', $Postal_Code);
		$encrypted_txt0 = encrypt_decrypt('encrypt', $Drivers);
		
		$encrypted_txt11 = encrypt_decrypt('encrypt', $Own_Car);
		$encrypted_txt12 = encrypt_decrypt('encrypt', $dog );
		$encrypted_txt13 = encrypt_decrypt('encrypt', $Permit);
		$encrypted_txt14 = encrypt_decrypt('encrypt', $Highest_Q);
		
		
		$fql=("UPDATE $tbl_name SET Name = '".$encrypted_txt1."', Surname = '".$encrypted_txt2."', Cellphone = '".$encrypted_txt3."', Gender = '".$encrypted_txt4."', Age = '".$encrypted_txt5."', Address = '".$encrypted_txt6."', City = '".$encrypted_txt7."', Country = '".$encrypted_txt8."', Highest_Q = '".$encrypted_txt14."', Postal_Code = '".$encrypted_txt9."', Drivers = '".$encrypted_txt0."' , Own_Car = '".$encrypted_txt11."', English = '".$encrypted_txt12."',  Permit = '".$encrypted_txt13."'  WHERE Email = '".$Email."' ");	

	if (mysqli_query($link,$fql))
  {  

		echo "Sucess";

  }	


	
	}
}

?>
	