
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Skills"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$skills=$_POST["Skills"]; 
$Achievements=$_POST["Achievements"];


	$sql="SELECT * FROM $tbll_name WHERE Email='".$company."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){


$fql=("UPDATE $tbll_name SET Email= '".$company."', Skills = '".$skills."', Achievements = '".$Achievements."' WHERE Email = '".$company."' ");


	
if (!mysqli_query($link,$fql))
  {  
  header("location: skills.php");

  }

header("location: skills.php");
	
	}
	else
	{
	
	$sql="INSERT INTO $tbll_name (Email, Skills, Achievements)
VALUES
( '$company', '$skills', '$Achievements' )";

if (!mysqli_query($link,$sql))
  {
  die('Error: ' . mysqli_error($link));
  }
 
	header("location: skills.php");
	
	}
	
	  ?>
 



