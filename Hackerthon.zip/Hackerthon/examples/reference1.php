
 <?php
	  
	  $company44 = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Past_Work"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Company=$_POST["field_name"][1];
$Person=$mark1=$_POST["field_name1"][1];
$Contact=$_POST["field_name2"][1];

$Company1=$_POST["field_name"][2]; 
$Person1=$mark1=$_POST["field_name1"][2];
$Contact1=$_POST["field_name2"][2];

$Compan2y=$_POST["field_name"][3]; 
$Person2=$mark1=$_POST["field_name1"][3];
$Contact2=$_POST["field_name2"][3];

$Company3=$_POST["field_name"][4]; 
$Person3=$mark1=$_POST["field_name1"][4];
$Contac3t=$_POST["field_name2"][4];

$Company4=$_POST["field_name"][5]; 
$Person4=$_POST["field_name1"][5];
$Contact4=$_POST["field_name2"][5];




	$sql="SELECT * FROM $tbll_name WHERE Email='".$company44."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){


$fql=("UPDATE $tbll_name SET Company1 = '".$Company."', Person1 = '".$Person."', Contact1 = '".$Contact."' , Company2 = '".$Company1."', Person2 = '".$Person1."', Contact2 = '".$Contact1."', Company3 = '".$Company2."', Person3 = '".$Person2."', Contact3 = '".$Contact2."', Company4 = '".$Company3."', Person4 = '".$Person3."', Contact4 = '".$Contact3."', Company5 = '".$Company4."', Person5= '".$Person4."', Contact5 = '".$Contact4."' WHERE Email = '".$company44."' ");


	
if (!mysqli_query($link,$fql))
  {  

  header("location: reference_edit.php");

  }

header("location: user.php");
	
	}
	else
	{
		
	$kql="INSERT INTO $tbll_name (Email, Company1, Person1, Contact1, Company2, Person2, Contact2, Company3, Person3, Contact3, Company4, Person4, Contact4, Company5, Person5, Contact5)
VALUES
( '$company44','$Company', '$Person', '$Contact', '$Company1', '$Person1', '$Contact1', '$Company2', '$Person2', '$Contact2', '$Company3', '$Person3', '$Contact3', '$Company4', '$Person4', '$Contact4')";

if (!mysqli_query($link,$kql))
  {
 	header("location: reference_edit.php");
  }
 else
	{
	header("location: user.php");
	}

	
	}

	  ?>
 



