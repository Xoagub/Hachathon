<?php

$Name=$_POST["Name"]; 

 setcookie("Name54", $Name, time()+360000); 
 
 header("location:Amend2.php");




?>