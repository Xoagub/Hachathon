<?php
	
$company999 = $_COOKIE["user"];
$company = $_COOKIE["company"];

$domain = "Botswana";

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Employement_History"; // Table name 
$db_name="motleesy_namtax"; // Table name 
$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$company999' AND Domain ='$domain' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	
	$Years3 = $row["Working_Experience"];
	$Years4 = $row["Supervisory_Years"];
	$status4 = $row["Employement_status"];
	
	$Company7 = $row["Company1"];
    $Years_employed1 = $row["Years_employed1"];
	$Position1 = $row["Position1"];
	$Company8 = $row["Company2"];
    $Years_employed2 = $row["Years_employed2"];
	$Position2 = $row["Position2"];
	$Company9 = $row["Company3"];
    $Years_employed3 = $row["Years_employed3"];
	$Position3 = $row["Position3"];
	$Company10 = $row["Company4"];
    $Years_employed4 = $row["Years_employed4"];
	$Position4 = $row["Position4"];
	$Company11 = $row["Company5"];
    $Years_employed5 = $row["Years_employed5"];
	$Position5 = $row["Position5"];


	
    
	
?>