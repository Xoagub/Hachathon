

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Register </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util1.css">
	<link rel="stylesheet" type="text/css" href="css/main1.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="register1.php" method="post">
					<?php 


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tb1_name="User_Profile"; // Table name 
$tb2_name="Company_Profile"; // Table name


// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");


$email = $_POST["email"];
$Name = $_POST["Name"];
$Surname = $_POST["Surname"];

$password = $_POST["password"];
$password1 = $_POST["password1"];

if($password === $password1)
{





	//escapes special characters in a string
		
		$email = mysqli_real_escape_string($con,$email);
		
		$firstName = mysqli_real_escape_string($con,$firstName);
		
			
		$password = mysqli_real_escape_string($con,$password);
		
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    
} else {
    exit( "Email address $email is considered invalid.\n");
	}
		
				$rql="SELECT * FROM $tb1_name WHERE Email='".$email."' ";



$result=mysqli_query($con, $rql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count == 0){

		$hash = password_hash($password, PASSWORD_DEFAULT);

$sql="INSERT INTO $tb1_name( Email, Name, Surname, Password)
VALUES
( '$email', '$Name','$Surname', '$hash' )";




require('class.phpmailer.php');
require('class.smtp.php');
require('class.pop3.php');

require_once "PHPMailerAutoload.php";

//PHPMailer Object
$mail = new PHPMailer;


//From email address and name
$mail->From = "recruitment@motlee-systems.com";
$mail->FromName = "Motlee-Systems";

//To address and name
$mail->addAddress("$email", "$lastName");
$mail->addAddress("$email"); //Recipient name is optional

//Address to which recipient will reply
$mail->addReplyTo("reply@yourdomain.com", "Reply");

$me = "hr@motlee-systems.com";
	
//Send HTML or Plain Text email
$mail->isHTML(true);

$Subject = "Registration on the Motlee HR Systems Recruitment Platform";
$text = "Dear $email, 

Welcome to the Motlee family.

You have successfully registered on the Motlee HR Systems recruitment platform as a job seeker. We look forward to easing your recruitment process!

Below are your login credentials:

Username: [$email]

Please click on the link below to continue your job seeking process:

 www.motlee-systems.com/Recruitment/Candidate/login.html

Our HR Platform also offers the following features:
-	Payroll Administration 
-	Leave Management 
-	Performance Management 
-	Timesheets 

Please visit our website to find out more: www.motlee-systems.com  
Motlee HR Systems
Kind Regards
HR Team.
 ". date('Y-m-d H:i:s');
 
 
$mail->Subject = "Registration at Motlee Payroll Systems Details";
$mail->Body = "Dear $email, <br><br>
Welcome to the Motlee family.<br><br>
You have successfully registered to the Motlee HR Systems recruitment platform as a job seeker We look forward to easing your recruitment process!<br>
Below are your login credentials:<br><br>
Username: [$email]
Password: [$password]<br><br>
Please click on the link below to continue your job seeking process:<br> www.motlee-systems.com/Recruitment/Candidate/login.html
<br><br>
Our system HR Platform also offers the following features:<br><br>
-	Payroll Administration <br>
-	Leave Management <br>
-	Performance Management <br>
-	Timesheets 
<br><br>
Please visit our website to find out more: www.motlee-systems.com  <br><br>
Motlee HR Systems
 .<br><br><br>Kind Regards<br><br>HR Team.
 ". date('Y-m-d H:i:s');
$mail->AltBody = "This is the plain text version of the email content";

   mail($email, "$Subject", $text, "From:" . $me);





if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
    
	
	setcookie("user", $email, time()+3600000); 
	setcookie("Surname", $Surname, time()+3600000); 
setcookie("company", $Name, time()+3600); 
echo '<a href="http://www.motlee-systems.com/Recruitment/Candidate/examples/user.php">Click here to enter </a>' ;


}
else
{
$me = "Email already in use";
}		
}else
{

echo "Passwords dont match";
}
		




	



?>


					<span class="login100-form-title p-b-34 p-t-27">
						Please Enter Details To Register
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="email" id="email" placeholder="email">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
						
					</div>
					
					<div class="wrap-input100 validate-input" data-validate = "Enter Name">
						<input class="input100" type="text" name="name" id="name" placeholder="Name">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>
					
					<div class="wrap-input100 validate-input" data-validate = "Enter Surname">
						<input class="input100" type="text" name="Surname" id="Surname" placeholder="Surname">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="password" id="password" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
					
						<div class="wrap-input100 validate-input" data-validate="Password">
						<input class="input100" type="password" name="password1" id="password" placeholder="Re-type Password">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>


					
						
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Register
						</button>
						
					</div>

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>

