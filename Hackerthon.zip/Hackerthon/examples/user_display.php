<?php


	
$user = $_COOKIE["user"];
$company = $_COOKIE["company"];

$count32 = $_COOKIE["country"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 
$db_name="motleesy_namtax"; // Table name 
$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 $domain = "Botswana";

$sql = "SELECT * FROM $tbll_name WHERE Email='$user' AND Domain = '$domain' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country3 = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$dog = $row["English"];
		$Permit = $row["Permit"];
$sp = $row["Specialty"];
$interest = $row["interest"];

	
?>