
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="High_School"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$School=$_POST["School"]; 
$Town=$_POST["Town"];
$Country=$_POST["Country"]; 
 
$Subject1=$_POST["field_name"][1];
$mark1=$_POST["field_name1"][1];
$Subject2=$_POST["field_name"][2];
$mark2=$_POST["field_name1"][2];
$Subject3=$_POST["field_name"][3];
$mark3=$_POST["field_name1"][3];
$Subject4=$_POST["field_name"][4];
$mark4=$_POST["field_name1"][4];
$Subject5=$_POST["field_name"][5];
$mark5=$_POST["field_name1"][5];
$Subject6=$_POST["field_name"][6];
$mark6=$_POST["field_name1"][6];
$Subject7=$_POST["field_name"][7];
$mark7=$_POST["field_name1"][7];
$Subject8=$_POST["field_name"][8];
$mark8=$_POST["field_name1"][8];


$Domain = "Botswana";




	$sql="SELECT * FROM $tbll_name WHERE Email='".$company."' AND Domain = '".$Domain."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){


$fql=("UPDATE $tbll_name SET Email= '".$company."', High_School = '".$School."', Town = '".$Town."', Country = '".$Country."', Subject1 = '".$Subject1."', Score1 = '".$mark1."', Subject2 = '".$Subject2."', Score2 = '".$mark2."', Subject3 = '".$Subject3."', Score3 = '".$mark3."', Subject4 = '".$Subject4."' , Score4 = '".$mark4."', Subject5 = '".$Subject5."', Score5 = '".$mark5."', Subject6 = '".$Subject6."', Score6 = '".$Score6."', Subject7 = '".$Subject7."' , Score7 = '".$mark7."' WHERE Email = '".$company."' AND Domain = '".$Domain."' ");


	
if (!mysqli_query($link,$fql))
  {  
  header("location: Education_edit.php");

  }

header("location: user.php");
	
	}
	else
	{
	
	$sql="INSERT INTO $tbll_name (Email, High_School, Town, Country, Subject1, Score1, Subject2, Score2, Subject3, Score3, Subject4, Score4, Subject5, Score5, Subject6, Score6, Subject7, Score7, Domain)
VALUES
( '$company', '$School', '$Town', '$Country', '$Subject1', '$mark1', '$Subject2', '$mark2', '$Subject3', '$mark3', '$Subject4', '$mark4', '$Subject5', '$mark5', '$Subject6', '$mark6', '$Subject7', '$mark7', '$Domain'  )";

if (!mysqli_query($link,$sql))
  {
  header("location: Education_edit.php");
  }
 
	header("location: user.php");
	
	}
	
	  ?>
 


