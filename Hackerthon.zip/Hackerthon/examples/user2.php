
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$sp=$_POST["sp"]; 
$Name1=$_POST["Name"]; 
$Surname1=$_POST["Surname"];
$email1=$_POST["Email"]; 
$Cellphone1=$_POST["Cellphone"];
$Gender1=$_POST["Gender"]; 
$Age1=$_POST["Age"];
$Address1=$_POST["Address"]; 
$City1=$_POST["City"];
$Po1=$_POST["Po"]; 
$Country1=$_POST["Country"];
$Q1=$_POST["Q"]; 
$Me1=$_POST["Me"];

$Drivers=$_POST["Drivers"];
$Own_Car=$_POST["Own_Car"];
$English=$_POST["English"];
$Permit=$_POST["Permit"];

$interest=$_POST["interest"];

if($email1 === $company)	
{

$fql=("UPDATE $tbll_name SET Email= '".$email1."', Name = '".$Name1."', Surname = '".$Surname1."', Cellphone = '".$Cellphone1."', Gender = '".$Gender1."', Age = '".$Age1."', Address = '".$Address1."', City = '".$City1."', Country = '".$Country1."', Highest_Q = '".$Q1."', About = '".$Me1."', Postal_Code = '".$Po1."', Drivers = '".$Drivers."' , Own_Car = '".$Own_Car."', English = '".$English."',  Permit = '".$Permit."', interest = '".$interest."', Specialty = '".$sp."'  WHERE Email = '".$company."' ");	

	if (!mysqli_query($link,$fql))
  {  
  header("location: user_edit.php");

  }	
	
	header("location: user.php");
	
}

$fql=("UPDATE $tbll_name SET Email= '".$email1."', Name = '".$Name1."', Surname = '".$Surname1."', Cellphone = '".$Cellphone1."', Gender = '".$Gender1."', Age = '".$Age1."', Address = '".$Address1."', City = '".$City1."', Country = '".$Country1."', Highest_Q = '".$Q1."', About = '".$Me1."', Postal_Code = '".$Po1."', Drivers = '".$Drivers."' , Own_Car = '".$Own_Car."', English = '".$English."',  Permit = '".$Permit."', interest = '".$interest."' , Specialty = '".$sp."'  WHERE Email = '".$company."' ");


if (!mysqli_query($link,$fql))
  {  
  header("location: user_edit.php");

  }

header("location: user.php");
	
	
	
	  ?>
 


