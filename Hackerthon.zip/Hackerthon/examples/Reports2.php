<?php

$Position=$_POST["Position"];

setcookie("beans", $Position, time()+36000);

header('Location: Reports1.php');
?>