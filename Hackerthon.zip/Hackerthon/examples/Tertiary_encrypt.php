

<?php 

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
  $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbl_name="Tertiary"; // Table name 

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query

$sql = "SELECT * FROM $tbl_name  ";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $Email = $row["Email"];
	$High_School = $row["University"];
    $Degree = $row["Degree"];
	$hey = $row["Highest"];
	$Field = $row["Field"];

	$Degree1 = $row["Qualification1"];
	$Field1 = $row["Field1"];
	$High_School1 = $row["University1"];

	$Degree2 = $row["Qualification2"];
	$Field2 = $row["Field2"];
	$High_School2 = $row["University2"];

	$Degree3 = $row["Qualification3"];
	$Field3 = $row["Field3"];
	$High_School3 = $row["University3"];

	$Degree4 = $row["Qualification4"];
	$Field4 = $row["Field4"];
	$High_School4 = $row["University4"];

		$encrypted_txt40 = encrypt_decrypt('encrypt',  $Email);
		$encrypted_txt41 = encrypt_decrypt('encrypt',  $High_scool);
		$encrypted_txt42 = encrypt_decrypt('encrypt', $Town);
		$encrypted_txt43 = encrypt_decrypt('encrypt', $hey);
		$encrypted_txt44 = encrypt_decrypt('encrypt', $Field);
		$encrypted_txt45 = encrypt_decrypt('encrypt', $Degree);
		$encrypted_txt46 = encrypt_decrypt('encrypt', $Degree1);
		$encrypted_txt47 = encrypt_decrypt('encrypt', $Field1);
		$encrypted_txt48 = encrypt_decrypt('encrypt', $High_School1);
		$encrypted_txt49 = encrypt_decrypt('encrypt', $Degree2);
		$encrypted_txt50 = encrypt_decrypt('encrypt', $Field2);
		
		$encrypted_txt51 = encrypt_decrypt('encrypt', $High_School2);
		$encrypted_txt52 = encrypt_decrypt('encrypt', $Degree3 );
		$encrypted_txt53 = encrypt_decrypt('encrypt', $Field3);
		$encrypted_txt54 = encrypt_decrypt('encrypt', $High_School3);
		
			$encrypted_txt56 = encrypt_decrypt('encrypt', $Degree4 );
		$encrypted_txt57 = encrypt_decrypt('encrypt', $Field4);
		$encrypted_txt58 = encrypt_decrypt('encrypt', $High_School4);

		
		
		$fql=("UPDATE $tbl_name SET University = '".$encrypted_txt41."', Town = '".$encrypted_txt42."', Degree = '".$encrypted_txt45."', Highest = '".$encrypted_txt43."', Field = '".$encrypted_txt45."', Qualification1 = '".$encrypted_txt46."', Field1 = '".$encrypted_txt47."', University1 = '".$encrypted_txt48."', Qualification2 = '".$encrypted_txt49."', Field2= '".$encrypted_txt50."', University2 = '".$encrypted_txt51."' , Qualification3 = '".$encrypted_txt52."', Field3 = '".$encrypted_txt53."',  University3 = '".$encrypted_txt54."', Qualification4 = '".$encrypted_txt56."', Field4 = '".$encrypted_txt57."', University4 = '".$encrypted_txt58."' WHERE Email = '".$Email."' ");	

	if (mysqli_query($link,$fql))
  {  

		echo "Sucess";

  }	


	
	}
}

?>
	