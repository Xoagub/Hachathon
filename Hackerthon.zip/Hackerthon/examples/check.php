

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"><link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
	

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
<?php 
 // Require https
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
           
             <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				
				 <h7 class="title"> 
				 <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

echo  " $me " ; ?></h7></div>
            </div>
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li>  <a href="dashboardc.php">
                
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                       
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li  class="active">
                        <a href="Load_Vacancy.php">
                        
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li>
                        <a href="prescreaning.php">
                         
                            <p>Pre-Screening Questions </p>
                        </a>
                    </li>
                     <li> <a href="History.php"> <p>Pre-Screening </p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Log Off</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Payment Check</h5>
                            </div>
                            <div class="card-body">

<?php 




	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Load_Vacancy"; // Table name 
$tb1_name="User_Profile"; // Table name
$tb2_name="advert"; 
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");

							
								
$ref = $_POST["p2"];
$amount = $_POST["p6"];	

if($ref != "" or $amount !="")

{

if ($sql="SELECT * FROM $tbll_name WHERE Reference='".$ref."' ");
{

$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

$wql="SELECT * FROM $tbll_name WHERE Reference='".$ref."' ";
$result2 = mysqli_query($link, $wql);
$details = mysqli_fetch_array($result2, MYSQLI_BOTH);
$Name = $details["Position"];
$me55 = $details["interest"];


// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){

$pay = "Paid";
// Register $myusername, $mypassword and redirect to file "login_success.php"

 $gql = "UPDATE $tbll_name SET Paid='".$pay."', Amount='".$amount."' WHERE Reference = '".$ref."' ";

if (!mysqli_query($link,$gql))
  {
echo "error";
  }

$tql = "SELECT * FROM $tb1_name WHERE interest = '$me55' ";

$result3 = $link->query($tql);
if ($result3->num_rows > 0) {
    // output data of each row
    while($row = $result3->fetch_assoc()) {
   	$email = $row["Email"];
	$Name1 = $row["Name"];
	$Surname2 = $row["Surname"];
 
$from = "recruitment@motlee-systems.com";

$to = "$email";
$subject = "New Vacancy Posted : $Name";
$mailtext = "Dear $Name1 $Surname2, 

Please be informed, a new vacancy for a $Name position has been posted on your profile. Log into your account to apply.

Link: [https://www.motlee-systems.com/Recruitment/]

Our HR Platform also offers the following features:
-	Payroll Administration 
-	Leave Management 
-	Performance Management 
-	Timesheets 

Please visit our website to find out more: www.motlee-systems.com  
Motlee HR Systems
Kind Regards 
HR Team.
". date('Y-m-d H:i:s');
 
 
$mail->Subject = "Forgot Motlee-Systems Recruitment Platform Details";
$mail->Body = "Dear $lastName, <br><br>
You have requested to reset your password.<br><br>

Below are your one time generated code and link:<br><br>
One Time Pin: [$randomString]
Link: www.motlee-systems.com/Recruitment/Candidate/reset.php <br><br>

Our system HR Platform also offers the following features:<br><br>
-	Payroll Administration <br>
-	Leave Management <br>
-	Performance Management <br>
-	Timesheets 
<br><br>
Please visit our website to find out more: www.motlee-systems.com  <br><br>
Motlee HR Systems
 .<br><br><br>Kind Regards<br><br>HR Team.
. date('Y-m-d H:i:s')";

mail($to, $subject, $mailtext, "From: $from "); 
echo "$nmail";
}}


echo "Succesfully recieved payment and your vacancy is posted ";
}

}

}else
{

echo "Payment not recieved ";
}
?>

 </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
