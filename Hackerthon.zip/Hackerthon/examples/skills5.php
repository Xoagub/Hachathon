<?php
	  

$user = $_COOKIE["user4"];
$company = $_COOKIE["company"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Skills"; // Table name 

$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	$Skills = $row["Skills"];
    $Achievements = $row["Achievements"];


	
	  ?>


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
             
				 <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                   <li>
                        <a href="User6.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                   
                     <li>
                        <a href="Education5.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>High school</p>
                        </a>
                    </li>
                     <li>
                        <a href="Tertiary5.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Tertiary Education</p>
                        </a>
                    </li>
                     <li>
                        <a href="Employment5.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Employment History </p>
                        </a>
                    </li>
                     <li>
                        <a href="skills5.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Skills</p>
                        </a>
                    </li>      <li>
                        <a href="reference5.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>References</p>     </a><li>  <li>
                        <a href="log_Off.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Skils/Achievements</h5>
                            </div>
                            <div class="card-body">
                                <form >
                                   
                                        
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Skils</label>
                                                <textarea rows="4" cols="80" name="Skills" id="Skills" class="form-control" placeholder="Describe your skills" ><?php echo $Skills ;?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Achievements</label>
                                                <textarea rows="4" cols="80" name="Achievements" id="Achievements" class="form-control" placeholder="Tell us your achievements" ><?php echo $Achievements ; ?> </textarea>
                                            </div>
                                        </div>
                                    </div>
			
				
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
