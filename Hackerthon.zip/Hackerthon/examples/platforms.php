<!DOCTYPE html>
<html lang="en">

<head>
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <!--- Basic Page Needs  -->
    <meta charset="utf-8">
    <title>Motlee Systems </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	
    <!-- Mobile Specific Meta  -->
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
	<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/style.css">
			
			<link rel="stylesheet" type="text/css" media="screen and (max-width: 360px)" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen and (min-width: 361px) and (max-width: 480px)" href="css/style.css">
<link rel="stylesheet" type="text/css" media="screen and (min-width: 481px)" href="css/style.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

	
</head>

<body  style="background-image: url('img/demo-thumb/bg-01.jpg');">
	<?php 
 // Require https
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
    <!-- prealoader area start -->
      <!--<div id="preloader">
        <div class="spiner"></div>
		<div class="logo"></div> -->
    </div>
    <!-- prealoader area end -->
    <!-- Crumbs area start -->
   
    <!-- Crumbs area end -->
    <!-- counter-box area start -->
   
    <!-- counter-box area end -->
    <!-- demo area start -->
	
	
    <div class="demo-area" >
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/1.jpg" >					
                        </div>
                        <div class="demo-title">
                             <h2> <a href="https://www.brightermonday.co.ke/" target="_blank" style="color: #0033FF " >Brighter Monday </a></h2>
                        </div>
                    </div>
                </div>
				
                <div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/NIEIS1.png" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://nieis.namibiaatwork.gov.na" target="_blank" style="color: #0033FF " >NIEIS </a></h2>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/Sage.png" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.jb.skillsmapafrica.com/JobSearch?SelectedCountryCode=NA&CountryList=System.Collections.Generic.List%601%5BSkillsMap.NewModels.Master.SelectableCountry%5D&CurrencyList=System.Collections.Generic.List%601%5BSkillsMap.NewModels.Master.SelectableCurrency%5D&InitiateSearch=True" target="_blank" style="color: #0033FF " >Sage Skills Map </a></h2>
                        </div>
                    </div>
                </div>
				 <div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/jobs.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.jobsunlimited.com.na/vacancies" target="_blank" style="color: #0033FF " >Jobs Unlimited</a></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                             <img src="img/demo-thumb/career241.jpg" alt="demo image">
                            
                        </div>
                        <div class="demo-title">
                              <h2> <a href="https://www.careers24.com/jobs/lc-namibia/" target="_blank" style="color: #0033FF ">Hr Careers 24</a> </h2>
                        </div>
                    </div>
                </div>
			
                <div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/pin.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.pinupjobs.com/" target="_blank" style="color: #0033FF " >Pin Up Jobs </a></h2>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/elite1.png" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="http://eliteemployment.com.na/jobs/" target="_blank" style="color: #0033FF " >Elite Employment Agency  </a></h2>
                        </div>
                    </div>
                </div>
				
					<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/career6.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.careerjet.com/jobs-in-namibia-122482.html" target="_blank" style="color: #0033FF " >Career jet   </a></h2>
                        </div>
                    </div>
                </div>
				
						<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/nam.png" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.namijob.com/" target="_blank" style="color: #0033FF " >Namijob   </a></h2>
                        </div>
                    </div>
                </div>
				
					
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/infin.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="http://infinity-rsa.com/jobs/" target="_blank" style="color: #0033FF " >Infinity Recruitment   </a></h2>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/namibian_oportunity.png" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="http://namibianopp.org/" target="_blank" style="color: #0033FF " >Namibian Opportunities   </a></h2>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/Vacancies.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.facebook.com/Vacancies-Namibia-1767303143492775/" target="_blank" style="color: #0033FF " >Facebook(Job Vacancies)  </a></h2>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/mtc.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="http://www.mtc.com.na/corporate/vacancies" target="_blank" style="color: #0033FF " >MTC  </a></h2>
                        </div>
                    </div>
                </div>
				
				
				<div class="col-md-4 col-sm-4 ">
                    <div class="demo-item">
                        <div class="thumb-area">
                          <img src="img/demo-thumb/linkedin.jpg" alt="demo image">
                           
                        </div>
                        <div class="demo-title">
                            <h2>  <a href="https://www.linkedin.com/" target="_blank" style="color: #0033FF " >linkedin   </a></h2>
                        </div>
                    </div>
                </div>
				
				
				
			</div>
                
              
               
                
                
            </div>
	</div>


   
    <!-- demo area end -->
<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Contact Details </h6>
								<p style="color:#000000" >Mail: hr@motlee-systems.com. <br> Contact number : +264 0816321231 <br> Location : 118 Robert Mugabe Avenue <br> Windhoek Namibia</p>
										
							</div>
						</div>
					
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget">
								<h6 class="mb-30">Key Partners</h6>
								<ul class="instafeed d-flex ">
									<li><img src="img/sanlam.png" width="110px" height="95px" ></li>
				   				<li><img src="img/NBII.png" width="115px" height="95px"  ></li>
				   				<li><img src="img/NUST.jpg" width="110px" height="85px"  ></li>
									<li><img src="img/dololo_white_man.png" width="75px" height="75px"></li>
									
								
								</ul>
							</div>
						</div>
					
					</div><div align="center">
					<p style="padding: 100px">		
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
	</div>
					
								 </div>
	

				</div>
			</footer>
    <!-- footer area start -->
    
    <!-- footer area end -->

    <!-- Scripts -->
    <script src="js/jquery-3.2.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animatedheadline.js"></script>
    <script src="js/counterup.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/theme.js"></script>
	
	<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>		
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
</body>

</html><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>