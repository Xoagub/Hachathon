
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Tertiary"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 

$High=$_POST["cool"]; 
$Field=$_POST["Field"];

$School=$_POST["School"]; 
$Town=$_POST["Town"];
$Country=$_POST["Country"]; 
$Degree=$_POST["Degree"]; 


$Degree1=$_POST["field_name"][1];
$Field1=$_POST["field_name1"][1];
$School1=$_POST["field_name2"][1];
$Degree2=$_POST["field_name"][2];
$Field2=$_POST["field_name1"][2];
$School2=$_POST["field_name2"][2];
$Degree3=$_POST["field_name"][3];
$Field3=$_POST["field_name1"][3];
$School3=$_POST["field_name2"][3];
$Degree4=$_POST["field_name"][4];
$Field4=$_POST["field_name1"][4];
$School4=$_POST["field_name2"][4];

$domain = "Botswana";


	$sql="SELECT * FROM $tbll_name WHERE Email='".$company."' AND Domain = '".$domain."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);


// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){


$fql=("UPDATE $tbll_name SET Email= '".$company."', University = '".$School."', Town = '".$Town."', Country = '".$Country."', Degree='".$Degree."', Highest = '".$High."', Field = '".$Field."', Qualification1='".$Degree1."', Field1 = '".$Field1."', University1 = '".$School."', Qualification2='".$Degree2."', Field2 = '".$Field2."', University2 = '".$School2."', Qualification3='".$Degree3."', Field3 = '".$Field3."', University3 = '".$School3."', Qualification4='".$Degree4."', Field4 = '".$Field4."', University4 = '".$School4."' WHERE Email= '".$company."' AND Domain = '".$domain."' ");


	
if (!mysqli_query($link,$fql))
  {  
  header("location: Tertiary_edit.php");

  }
 header("location: user.php");

	
	}
	else
	{
	
	$gql="INSERT INTO $tbll_name (Email, University, Town, Country, Degree, Highest, Field, Qualification1, Field1, University1, Qualification2, Field2, University2, Qualification3, Field3, University3, Qualification4, Field4, University4, Domain)
VALUES
( '$company', '$High_School', '$Town', '$Country', '$Degree', '$Highest', '$Field', '$Degree1', '$Field1', '$School1', '$Degree2', '$Field2', '$School2', '$Degree3', '$Field3', '$School3' , '$Degree4', '$Field4', '$School4', '$domain'  )";

if (!mysqli_query($link,$gql))
  {
  header("location: Tertiary_edit.php");
  }
 
	header("location: user.php");
	
	}
	
	  ?>
 


