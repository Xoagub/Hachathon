<?php
	

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
  $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}


$user = $_COOKIE["user"];
$company = $_COOKIE["company"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 

$Final="yes";



// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
  	$Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country3 = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$dog = $row["English"];
		$Permit = $row["Permit"];
   
$decrypted_txt1 = encrypt_decrypt('decrypt', $Name);
$decrypted_txt2 = encrypt_decrypt('decrypt', $Surname );
$decrypted_txt3 = encrypt_decrypt('decrypt', $Cellphone);
$decrypted_txt4= encrypt_decrypt('decrypt', $Gender);
$decrypted_txt5 = encrypt_decrypt('decrypt', $Age);
$decrypted_txt6 = encrypt_decrypt('decrypt', $Address);
$decrypted_txt7 = encrypt_decrypt('decrypt', $City);
$decrypted_txt8 = encrypt_decrypt('decrypt', $Country3);
$decrypted_txt9 = encrypt_decrypt('decrypt', $Highest_Q);
$decrypted_txt10 = encrypt_decrypt('decrypt', $Drivers);
$decrypted_txt11 = encrypt_decrypt('decrypt', $Own_Car);
$decrypted_txt12 = encrypt_decrypt('decrypt', $dog );
$decrypted_txt13 = encrypt_decrypt('decrypt', $Permit );

    
	
?>