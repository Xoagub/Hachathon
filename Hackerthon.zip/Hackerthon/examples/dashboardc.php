<?php
  $dir = 'img/';
  // Initiate array which will contain the image name
  $imgs_arr = array();
  // Check if image directory exists
  if (file_exists($dir) && is_dir($dir) ) {
    
      // Get files from the directory
      $dir_arr = scandir($dir);
      $arr_files = array_diff($dir_arr, array('.','..') );
      foreach ($arr_files as $file) {
        //Get the file path
        $file_path = $dir."/".$file;
        // Get extension
        $ext = pathinfo($file_path, PATHINFO_EXTENSION);
        if ($ext=="jpg" || $ext=="png" || $ext=="JPG" || $ext=="PNG") {
          array_push($imgs_arr, $file);
        }
        
      }
      $count_img_index = count($imgs_arr) - 1;
      $random_img = $imgs_arr[rand( 0, $count_img_index )];
  }
?>

<?php 
$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];
// get supervisor email
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 

$tbl1_name="Load_Vacancy";
$tbl2_name="Company_Profile";
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB"); 





$active ="active";


$query = "SELECT * FROM $tbl1_name  WHERE Company_Name = '$Surname1' 
 "; //Write a query
$data = mysqli_query($link, $query);  //Execute the query
$num = mysqli_num_fields($link, $query);

?>


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
	


	
<meta name="robots" content="noindex,follow" />


</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				 <h7 class="title"> <?php

$company = $_COOKIE["user"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 

$me = $_COOKIE["company"];

echo  "  $Surname1" ; 
?></h7>
</div>
            </div>
         
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li class="active">  <a href="dashboardc.php">
                          
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                           
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li>
                        <a href="Load_Vacancy.php">
                         
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li>
                        <a href="prescreaning.php">
                          
                            <p>Prescreening question </p>
                        </a>
                    </li>
                     <li> <a href="History.php"> <p>Pre-Screening </p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
          
			<div class="slideshow-container">


<div>
<img src="<?php echo $dir."/".$random_img ?>">
</div>


</div>

            <div class="content">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card card-chart">
                      
                           
                            
                        </div>
                    </div>
               
              
                </div>
                <div class="row">
               
                  <div class="col-md-9">
                      <div class="card">
                        <div class="card-header">
                            <h5 class="card-category">Vacancy History</h5>
                            <h4 class="card-title"></h4>
                        </div>
                        <div class="card-body">
                           
 <table class="table">
                                        <thead class=" text-primary">
                                           
                                            <th style="color:#0033FF">
                                               Position
                                            </th>
                                            <th style="color:#0033FF">
                                                Closing Date
                                            </th>
											  <th style="color:#0033FF">
                                               Total Applicants
                                            </th>
                                           
                                        </thead>
		     <?php
while($fetch_options = mysqli_fetch_array($data)) { //Loop all the options retrieved from the query

$cat = $fetch_options['User']; 
?>



		    <tbody>
			<tr >
			    	   
		
			    <td><?php echo $fetch_options['Position'];  ?></td>
			    <td><?php echo $fetch_options['Closing_Date'];  ?></td>
				<td><?php echo $fetch_options['Total_Applicants'];  ?></td>
			   
			    			<?php
}
?>
			</tr>

		    </tbody>
		</table>                         
                        </div>
                      </div>
                  </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
							</li>
                            
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Recruitment
                        
                    </div>
                </div>
            </footer>
        </div>
    </div>
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="js/jquery.nivo.slider.pack.js"></script>
<script>
	$(window).load(function() {
		$('#slider').nivoSlider({
			effect: 'random',
			directionNavHide: false,
			pauseOnHover: true,
			captionOpacity: 1,
			prevText: '<',
			nextText: '>'
		});
	});
</script>

</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
