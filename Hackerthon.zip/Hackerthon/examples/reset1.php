<!DOCTYPE html>
<html lang="en">
<head>
	<title>Register </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="shortcut icon" type="image/x-icon" href="banner.png" />
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util1.css">
	<link rel="stylesheet" type="text/css" href="css/main1.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="forgot1.php" method="post">
					<?php 


include("conn.php");


$email = $_POST["pin"];

$password = $_POST["pass"];
$password1 = $_POST["pass1"];

if($password === $password1)
{


$domain ="Kenya";


	//escapes special characters in a string
		
		$email = mysqli_real_escape_string($con,$email);
		
		$firstName = mysqli_real_escape_string($con,$firstName);
		
			
		$password = mysqli_real_escape_string($con,$password);
		

		
$rql="SELECT * FROM $tb1_name WHERE Generated_String ='".$email."' AND Domain = '".$domain."' ";
				
$wql="SELECT * FROM $tb1_name WHERE  Generated_String='".$email."' AND Domain = '".$domain."' ";
$result2 = mysqli_query($con, $wql);
$details = mysqli_fetch_array($result2, MYSQLI_BOTH);
$Name = $details["Name"];
$Surname = $details["Surname"];
$email1 = $details["Email"];


$result=mysqli_query($con, $rql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count === 1){

		$hash = password_hash($password, PASSWORD_DEFAULT);

$gql = "UPDATE $tb1_name SET Password='".$hash."' WHERE Generated_String= '".$email."' AND Domain = '".$domain."' ";

if ($con->query($gql) === TRUE) {

echo "$Name, you have successfully updated password";
echo '<a href="http://www.motlee-systems.com/Kenya/Recruitment/Candidate/user.php">Click here to log in </a>' ;


} else {
    echo "Error updating record: " ;
}




require('class.phpmailer.php');
require('class.smtp.php');
require('class.pop3.php');

require_once "PHPMailerAutoload.php";

//PHPMailer Object
$mail = new PHPMailer;


//From email address and name


 

$from = "recruitment@motlee-systems.com";
$to = "$email1";
$subject = "Forgot Motlee-Systems Recruitment Platform Details";
$mailtext = "Dear $Name $Surname, 

Your Request to reset your password has been successfull.

Click here to login www.motlee-systems.com/Kenya/ 


 
Kind Regards
Motlee HR Systems
HR Team
". date('Y-m-d H:i:s');
 
 


mail($to, $subject, $mailtext, "From: $from "); 
 
}
else
{
echo "Invalide details";
}		
}else
{

echo "Passwords dont match";
}
		




	



?>


					<span class="login100-form-title p-b-34 p-t-27">
						Please Enter One time pin and new password 
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="pin" id="pin" placeholder="One time pin">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="password" name="pass" id="pass" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="password" name="pass" id="pass" placeholder="Re type password">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

				

					
						
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Reset
						</button>
						
					</div>

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>