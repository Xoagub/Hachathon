<?php

require('fpdf.php');

$Nationality = $_COOKIE["beans"];


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name
$tbl2_name="Apply"; // Table name 
$tbl3_name="User_Profile"; // Table name
// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");



$fg = "Interview";

$jkl = "SELECT * FROM $tbl2_name WHERE Application_ID = '".$Nationality."' AND Interview = '".$fg."' ORDER BY Points DESC ";
$result86 = mysqli_query($conn, $jkl);


class PDF extends FPDF
{
	}
$pdf=new PDF();	


	if (mysqli_num_rows($result86) > 0) {
		
    // output data of each row
    while($row85 = $result86->fetch_assoc()) {
		$User = $row85["User"];
		$Points = $row85["Points"];

	




	   
	$uql = "SELECT * FROM  $tbl3_name WHERE Email='$User' ";
$result3 = $conn->query($uql);

    // output data of each row
	$result3 = mysqli_query($conn, $uql);
    $row2 = mysqli_fetch_array($result3, MYSQLI_BOTH);
    $Working_Experience = $row2["Name"];
	$Supervisory_Years = $row2["Surname"];
	$Employement_status = $row2["Cellphone"];
	$Numbe = $row2["Gender"];

	$Surname = $row2["Address"];
	$DOB = $row2["City"];
	$Place_birth = $row2["Country"];
	





		
$pdf->AddPage();

$pdf->SetFont('Arial','',10);
$txt4 ="Name :$Working_Experience";
$txt="Surname: 	$Supervisory_Years";
$txt3="Cellphone : $Employement_status";
$txt2="Gender: $Numbe";
$txt5 ="Address : $Surname";
$txt6 = "City :$DOB";
$txt7 = "Country:$Place_birth";
$txt8 = "Email:$User";
$txt12 = "Points : $Points%";

$text = "Earnings";
	$pdf->Cell(133.5, 2.7, $txt4, 0, 0, 'L');
	$pdf->Cell(45.5, 3.7, $txt, 0, 1, 'L');
	$pdf->Cell(133.5, 4.7, $txt2, 0, 0, 'L');
	$pdf->Cell(45.5, 3.7, $txt3, 0, 1, 'L');
	$pdf->Cell(133.5, 4.7, $txt5, 0, 0, 'L');
	$pdf->Cell(45.5, 3.7, $txt6, 0, 1, 'L');
	$pdf->Cell(133.5, 4.7, $txt7, 0, 0, 'L');
	$pdf->Cell(45.5, 3.7, $txt8, 0, 1, 'L');


	$pdf->SetFont('Arial','B',20);
	    $path = public_path() . '../../Candidate/examples/upload/';

    $filepath = $path . $User . jpg;

    if(file_exists($filepath)) {
        $pdf->Image($filepath,'10','10','30','30');
    }
	
		
	$pdf->SetY(80);
$pdf->MultiCell(115,10,$txt12,0,0);





	}
		}
$pdf->Output();


?>