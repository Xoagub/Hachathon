
 <?php

 $company99 = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

$domain = "Botswana";
	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Employement_History"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 


$Years1=$_POST["Years1"];
$status=$_POST["status"];

$Company=$_POST["field_name"][1]; 
$Years_employed=$_POST["field_name2"][1];
$Position=$_POST["field_name1"][1]; 
$Company1=$_POST["field_name2"][2]; 
$Years_employed1=$_POST["field_name2"][2];;
$Position1=$_POST["field_name1"][2]; 
$Company2=$_POST["field_name"][3]; 
$Years_employed2=$_POST["field_name2"][3];
$Position2=$_POST["field_name1"][3];
$Company3=$_POST["field_name"][4]; 
$Years_employed3=$_POST["field_name2"][4];
$Positio3n=$_POST["field_name1"][4];
$Company4=$_POST["field_name"][5]; 
$Years_employed4=$_POST["field_name2"][5];
$Position4=$_POST["field_name1"][5];


$Years= $Years_employed + $Years_employed1 + $Years_employed2 + $Years_employed3 + $Years_employed4 ;


	$sql="SELECT * FROM $tbll_name WHERE Email='".$company99."' AND Domain = '".$domain."' ";


$result=mysqli_query($link, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

$one = 1 ;


// If result matched $myusername and $mypassword, table row must be 1 row
if($count===$one){


$fql=("UPDATE $tbll_name SET Email= '".$company99."', Working_Experience= '".$Years."', Supervisory_Years = '".$Years1."' ,Employement_status = '".$status."', Company1 = '".$Company."', Years_employed1 = '".$Years_employed."', Position1 = '".$Position."',Company2 = '".$Company1."', Years_employed2 = '".$Years_employed1."', Position2 = '".$Position1."' ,Company3 = '".$Company2."', Years_employed3 = '".$Years_employed2."', Position3 = '".$Position2."', Company4 = '".$Company3."', Years_employed4 = '".$Years_employed3."', Position4 = '".$Position3."', Company5 = '".$Company4."', Years_employed5 = '".$Years_employed4."', Position5 = '".$Position4."'  WHERE Email = '".$company99."'  and Domain = '".$domain."' ");


	
if (mysqli_query($link,$fql))
  {  
  header("location: Employment_edit.php");

  }

header("location: user.php");
	
	}
	else
	{
	
	$oql="INSERT INTO $tbll_name (Email, Working_Experience, Supervisory_Years, Employement_status, Company1, Years_employed1, Position1, Company2, Years_employed2, Position2, Company3, Years_employed3, Position3, Company4, Years_employed4, Position4, Company5, Years_employed5, Position5, Domain)
VALUES
( '$company99', '$Years', '$Years1', '$status', '$Company', '$Years_employed', '$Position', '$Company1', '$Years_employed1', '$Position1', '$Company2', '$Years_employed2', '$Position2', '$Company3', '$Years_employed3', '$Position3', '$Company4', '$Years_employed4', '$Position4', '$domain'  )";

if (mysqli_query($link,$oql))
  {
		header("location: Employment_edit.php");
  
  }
 
	header("location: user.php");

	}
	
	  ?>
 


