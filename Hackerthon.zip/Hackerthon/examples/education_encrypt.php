

<?php 

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
  $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbl_name="High_School"; // Table name 

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query

$sql = "SELECT * FROM $tbl_name  ";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   	$Email = $row["Email"];
    $High_scool = $row["High_School"];
	$Town = $row["Town"];
	$Country5 = $row["Country"];
	$Subject1 = $row["Subject1"];
	$Score1 = $row["Score1"];
			$Subject2 = $row["Subject2"];
	$Score2 = $row["Score2"];
			$Subject3 = $row["Subject3"];
	$Score3 = $row["Score3"];
			$Subject4 = $row["Subject4"];
	$Score4 = $row["Score4"];
			$Subject5 = $row["Subject5"];
	$Score5 = $row["Score5"];
			$Subject6 = $row["Subject6"];
	$Score6 = $row["Score6"];
			$Subject7 = $row["Subject7"];
	$Score7 = $row["Score7"];


		$encrypted_txt16 = encrypt_decrypt('encrypt',  $Email);
		$encrypted_txt1 = encrypt_decrypt('encrypt',  $High_scool);
		$encrypted_txt2 = encrypt_decrypt('encrypt', $Town);
		$encrypted_txt3 = encrypt_decrypt('encrypt', $Country5);
		$encrypted_txt4 = encrypt_decrypt('encrypt', $Subject1);
		$encrypted_txt5 = encrypt_decrypt('encrypt', $Score1);
		$encrypted_txt6 = encrypt_decrypt('encrypt', $Subject2);
		$encrypted_txt7 = encrypt_decrypt('encrypt', $Score2);
		$encrypted_txt8 = encrypt_decrypt('encrypt', $Subject3);
		$encrypted_txt9 = encrypt_decrypt('encrypt', $Score3);
		$encrypted_txt0 = encrypt_decrypt('encrypt', $Subject4);
		
		$encrypted_txt11 = encrypt_decrypt('encrypt', $Score4);
		$encrypted_txt12 = encrypt_decrypt('encrypt', $Subject6 );
		$encrypted_txt13 = encrypt_decrypt('encrypt', $Score6);
		$encrypted_txt14 = encrypt_decrypt('encrypt', $Subject7);
		$encrypted_txt15 = encrypt_decrypt('encrypt', $Score7);
		
		
		$fql=("UPDATE $tbl_name SET High_School = '".$encrypted_txt1."', Town = '".$encrypted_txt2."', Country = '".$encrypted_txt3."', Subject1 = '".$encrypted_txt4."', Score1 = '".$encrypted_txt5."', Subject2 = '".$encrypted_txt6."', Score2 = '".$encrypted_txt7."', Subject3 = '".$encrypted_txt8."', Score4 = '".$encrypted_txt14."', Subject4 = '".$encrypted_txt9."', Score5 = '".$encrypted_txt0."' , Subject5 = '".$encrypted_txt11."', Subject6 = '".$encrypted_txt12."',  Score6 = '".$encrypted_txt13."', ,  Subject7 = '".$encrypted_txt14."', ,  Score7 = '".$encrypted_txt15."' WHERE Email = '".$Email."' ");	

	if (mysqli_query($link,$fql))
  {  

		echo "Sucess";

  }	


	
	}
}

?>
	