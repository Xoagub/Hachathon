<?php
	

$user = $_COOKIE["user"];
$company = $_COOKIE["company"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Tertiary"; // Table name 
$db_name="motleesy_namtax"; // Table name 
$Final="yes";

$Domain = "Botswana";


// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' AND Domain = '$Domain' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	$High_School = $row["University"];
    $Degree = $row["Degree"];
	$hey = $row["Highest"];
	$Field = $row["Field"];

	$Degree1 = $row["Qualification1"];
	$Field1 = $row["Field1"];
	$High_School1 = $row["University1"];

	$Degree2 = $row["Qualification2"];
	$Field2 = $row["Field2"];
	$High_School2 = $row["University2"];

	$Degree3 = $row["Qualification3"];
	$Field3 = $row["Field3"];
	$High_School3 = $row["University3"];

	$Degree4 = $row["Qualification4"];
	$Field4 = $row["Field4"];
	$High_School4 = $row["University4"];





	
    
	
?>