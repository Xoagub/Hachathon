
 <?php
// salt = "7354737392469361"	  

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

	
$Surname1 = $_COOKIE["Surname"];


	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="encrypt"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");




$plain_txt = "$Surname1";
echo "Plain Text =" .$plain_txt. "\n";
$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);


$sql="INSERT INTO $tbll_name (tes)
VALUES
( '$encrypted_txt'  )";
	

	if (mysqli_query($link,$sql))
  {  
  echo "Success";

  }	





	
	
	
	  ?>
 


