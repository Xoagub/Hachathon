 






<?php
	  
	  $Surname1 = $_COOKIE["company"];
	  $company6 = $_COOKIE["user"];


	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Load_Vacancy"; // Table name 
$tb1_name="User_Profile"; // Table name 
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Close=$_POST["Close"]; 
$Requirements=$_POST["Requirements"];
$Description=$_POST["Description"]; 
$Skills=$_POST["Skills"];
$Qualifications=$_POST["Qualifications"];
$Contact=$_POST["Contact"];
$Person=$_POST["Person"];
$New_old=$_POST["New_old"];
$Level=$_POST["Level"];
$grade=$_POST["grade"];
$Vacancies=$_POST["Vacancy"];
$Name=$_POST["Name"];
$type=$_POST["type"];
$years=$_POST["Years"];



$sql="INSERT INTO $tbll_name (Position, Number_Vacancies,Job_Grade, Level_Operation, New_Old_Position, Contact_Person, Contact_Details, Years_Experince, Qualifications, Skills, Job_Description, Role_Requirement, Closing_Date, Company, Company_Name, type)
VALUES
( '$Name', '$Vacancies', '$grade', '$Level', '$New_old', '$Person', '$Contact','$years', '$Qualifications', '$Skills', '$Description', '$Requirements', '$Close', '$company6', '$Surname1', '$type')";

if (!mysqli_query($link,$sql))
  {
echo "error";
  }
  
  $tql = "SELECT * FROM $tb1_name ";

$result = $link->query($tql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   	$email = $row["Email"];
	$Name1 = $row["Name"];
	$Surname = $row["Surname"];
 
$from = "recruitment@motlee-systems.com";

$to = "$email";
$subject = "New Vacancy Posted : $Name1";
$mailtext = "Dear $Name1 $Surname, 
A new Vacancy has been uploaded, The Vacancy is $Name . Please log onto our systems to apply.


Link: [https://www.motlee-systems.com/Recruitment/]

Our system HR Platform also offers the following features:
-	Payroll Administration 
-	Leave Management 
-	Performance Management 
-	Timesheets 

Please visit our website to find out more: www.motlee-systems.com  
Motlee HR Systems
 .Kind Regards 
 HR Team.
 ". date('Y-m-d H:i:s');
 
 
$mail->Subject = "Forgot Motlee-Systems Recruitment Platform Details";
$mail->Body = "Dear $lastName, <br><br>
You have requested to reset your password.<br><br>

Below are your one time generated code and link:<br><br>
One Time Pin: [$randomString]
Link: www.motlee-systems.com/Recruitment/Candidate/reset.php <br><br>

Our system HR Platform also offers the following features:<br><br>
-	Payroll Administration <br>
-	Leave Management <br>
-	Performance Management <br>
-	Timesheets 
<br><br>
Please visit our website to find out more: www.motlee-systems.com  <br><br>
Motlee HR Systems
 .<br><br><br>Kind Regards<br><br>HR Team.
. date('Y-m-d H:i:s')";
mail($to, $subject, $mailtext, "From: $from "); 

}}



  header("location: Load_Vacancy.php");
	
	
	  ?>