 
 <?php
 

	  
	
$user = $_GET['var']; 

setcookie("user4", $user, time()+360000); 

header("location: User6.php");

?>