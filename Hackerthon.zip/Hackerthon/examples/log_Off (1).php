			     <?php
	
// set the expiration date to one hour ago
setcookie("company", "", time() - 36000);
setcookie("user", "", time() - 36000);

header("location: /Recruitment");

?>