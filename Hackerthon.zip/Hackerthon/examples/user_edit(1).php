 
 <?php
	  
	  include('user_display.php');
	  
	
	  
	
	  
 
//Create a DateTime object using the user's date of birth.
$dob = new DateTime($Age);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age1 = $difference->y;
	
	  ?>



<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
	
	<script>
$(function()
{
  $(".js-example-basic-multiple").select2();
});
</script>
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				 <h7 class="title"> <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$data2 = ".jpg";
$result = $company . $data2;

$data3 = ".pdf";
$result1 = $company . $data3;

if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div></h7>
</div>
            </div>
            <div class="sidebar-wrapper">
                      <ul class="nav">  		 <li class="active">
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                    <li >
                        <a href="dashboard.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>History</p>
                        </a>
                    </li>
                 <li>
                        <a href="apply.php">
                             <i class="now-ui-icons gestures_tap-01"></i><p>Vacancies</p>     </a></li>
                
                   <li>
                        <a href="../../../platforms.php" target="_blank" >
                               <i class="now-ui-icons location_world"></i> <p>Explore</p>     </a></li> 
					<li class="">
                        <a  href="../../../courses.php" target="_blank">
                               <i class="now-ui-icons education_hat"></i>
                            <p>E-Learning</p>
                        </a>
                    </li>
                   
                    <li>
                        <a href="log_Off.php">
                              <i class="now-ui-icons sport_user-run"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid" >
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler" style="background-color: #0033FF">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                     
                    </div>
                   
                  
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Profile</h5>
                            </div>
                            <div class="card-body">
                                <form action="user2.php" method="post">
                                   <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Name: </label>
                                                  <input type="text"  style="color:black" class="form-control" placeholder=""  name="Name" value="<?php echo $Name ; ?>">
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Surname: </label>
                                                 <input type="text"  style="color:black" class="form-control" placeholder=""  name="Surname" value=" <?php echo $Surname ; ?>">
                                            </div>
                                        </div></div>
										
                                          <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address:</label>
                                                <input type="email" class="form-control" style="color: black" placeholder="Email" id="Email" name="Email" value="<?php echo $Email ; ?>">
                                            </div>
                                        </div>
										                                    </div>
								
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Cellphone:</label>
                                                <input type="number" class="form-control" style="color: black" placeholder="Cellphone" id="Cellphone" name="Cellphone" value="<?php echo $Cellphone ;?>" >
                                            </div>
                                        </div>
										</div>
                                         <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Gender:</label>
                                                <select name="Gender" id="Gender" class="form-control" style="color: black">
												<option selected="selected" value="<?php echo $Gender;?>"><?php echo $Gender;?></option>
 													 <option value="Male">Male</option>
  													<option value="Female">Female</option>
 												</select>
                                                
                                            </div>
                                        </div>
										</div>
										  <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Drivers:</label>
                                                <select name="Drivers" id="Drivers" style="color: black" class="form-control">
												<option selected="selected" value="<?php echo $Drivers ;?>"><?php echo $Drivers;?></option>
												<option value="None">None</option>
 													 <option value="A">A</option>
  													<option value="B">B</option>
													 <option value="BE">BE</option>
  													<option value="C1">C1</option>
													<option value="C">C</option>
													<option value="CE">CE</option>
													
													
 												</select>
                                                
                                            </div>
                                        </div>
										</div>
										 <div class="row">
										  <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Own Car:</label>
                                                <select name="Own_Car" id="Own_Car" style="color: black" class="form-control">
												<option selected="selected" value="<?php echo $Own_Car ;?>"><?php echo $Own_Car;?></option>
 													 <option value="Yes">Yes</option>
  													<option value="No">No</option>
																									
 												</select>
                                                
                                            </div>
                                        </div>
                                    </div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Date Of Birth:</label>
                                                <input type="date" name="Age" id="Age" style="color: black" class="form-control" placeholder="Age" value="<?php echo $Age ; ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address:</label>
                                                 <input type="text"  style="color:black" name="Address" id="Address" class="form-control" placeholder="Home Address" value="<?php echo $Address ; ?>" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>City:</label>
                                                 <input type="text"  style="color:black" name="City" id="City" class="form-control" placeholder="City" value="<?php echo $City ; ?>">
                                            </div>
                                        </div>
										</div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Country:</label>
                                              
												<select name="Country" id="Country" style="color: black" class="form-control">
												<option selected="selected" value="<?php echo $Country ; ?>"><?php echo $Country3 ; ?></option>
  <option value="Afghanistan">Afghanistan</option>
  <option value="Algeria">Algeria</option>
  <option value="Angola">Angola</option>
<option value="Argentina">Argentina</option>
  <option value="Austria">Austria</option>
  <option value="Australia">Australia</option>
<option value="Bangladesh">Bangladesh</option>
  <option value="Belarus">Belarus</option>
  <option value="Belgium">Belgium</option>
<option value="Bolivia">Bolivia</option>
  <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
  <option value="Brazil">Brazil</option>
<option value="Britain">Britain</option>
  <option value="Bulgaria">Bulgaria</option>
  <option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
  <option value="Canada">Canada</option>
  <option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
  <option value="China">China</option>
  <option value="Colombia">Colombia</option>
<option value="Costa Rica">Costa Rica</option>
  <option value="Croatia">Croatia</option>
  <option value="the Czech Republic">the Czech Republic</option>
<option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
  <option value="Denmark">Denmark</option>
  <option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
  <option value="El Salvador">El Salvador</option>
  <option value="England">England</option>
<option value="Estonia">Estonia</option>
  <option value="Ethiopia">Ethiopia</option>
  <option value="Finland">Finland</option>
<option value="France">France</option>
  <option value="Germany">Germany</option>
  <option value="Ghana">Ghana</option>
<option value="Greece">Greece</option>
  <option value="Guatemala">Guatemala</option>
  <option value="Holland">Holland</option>
<option value="Honduras">Honduras</option>
  <option value="Hungary">Hungary</option>
  <option value="Iceland">Iceland</option>
<option value="India">India</option>
  <option value="Indonesia">Indonesia</option>
  <option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
  <option value="Ireland">Ireland</option>
  <option value="Israel">Israel</option>
<option value="Italy">Italy</option>
  <option value="Ivory Coast">Ivory Coast</option>
  <option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
  <option value="Jordan">Jordan</option>
  <option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
  <option value="Laos">Laos</option>
  <option value="Latvia">Latvia</option>
<option value="Libya">Libya</option>
  <option value="Lithuania">Lithuania</option>
  <option value="Madagascar">Madagascar</option>
<option value="Malaysia">Malaysia</option>
  <option value="Mali">Mali</option>
  <option value="Mauritania">Mauritania</option>
<option value="Mexico">Mexico</option>
  <option value="Morocco">Morocco</option>
  <option value="Namibia">Namibia</option>
<option value="New Zealand">New Zealand</option>
  <option value="Nicaragua">Nicaragua</option>
  <option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
  <option value="Norway">Norway</option>
  <option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
  <option value="Panama">Panama</option>
  <option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
  <option value="The Philippines">The Philippines</option>
  <option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
  <option value="Republic of the Congo">Republic of the Congo</option>
  <option value="Romania">Romania</option>
<option value="Russia">Russia</option>
  <option value="Saudi Arabia">Saudi Arabia</option>
  <option value="Scotland">Scotland</option>
<option value="Senegal">Senegal</option>
  <option value="Serbia">Serbia</option>
  <option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
  <option value="Somalia">Somalia</option>
  <option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
  <option value="Sudan">Sudan</option>
  <option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
  <option value="Syria">Syria</option>
  <option value="Thailand">Thailand</option>
  <option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
  <option value="Turkmenistan">Turkmenistan</option>
  <option value="Ukraine">Ukraine</option>
<option value="The United Arab Emirates">The United Arab Emirates</option>
  <option value="The United States">The United States</option>
  <option value="Uruguay">Uruguay</option>
<option value="Vietnam">Vietnam</option>
  <option value="Wales">Wales</option>
  <option value="Zambia">Zambia</option>
  <option value="Zimbabwe">Zimbabwe</option>
 </select>
                                            </div>
                                        </div>
										</div>
                                         <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Postal Adress:</label>
                                                <input type="number" style="color: black" name="Po" id="Po" class="form-control" placeholder="ZIP Code" value="<?php echo $Postal_Code ; ?>">
                                            </div>
                                        </div>
                                    </div>
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>English:</label>
                                                  <select name="English" id="English" style="color: black" class="form-control">
												  <option selected="selected" value="<?php echo $dog;?>"><?php echo $dog;?></option>
 													 <option value="Good">Good</option>
  													<option value="Fair">Fair</option>
													<option value="Weak">Weak</option>
  													
																									
 												</select>
                                            </div>
                                        </div>
                                    </div>
									 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Industry:</label>
                                                 <select class="form-control" name="interest"  style="color: black">
  <option value="Finance/Banking">Finance and Banking</option>
  <option value="Aerospace">Aerospace </option>
  <option value="Transport/Logistic">Transport/ Logistics </option>
  <option value="Computer Science/IT">Computer/I.T</option>
													 
	<option value="Hospitality">Hospitality</option>
  <option value="Agriculture">Agriculture </option>
  <option value="Construction">Construction </option>
  <option value="Education">Education </option>
													 
	<option value="Pharmaceutical">Pharmaceutical </option>
  <option value="Safety and Security">Safety and Security</option>
  <option value="Health">Health Care </option>
  <option value="Entertainment">Entertainment </option>
 <option value="Energy">Energy </option>
  <option value="Manufacturing">Manufacturing </option>
  <option value="Media">Media </option>
													 
<option value="Mining">Mining </option>
  <option value="Electronics">Electronics </option>
<option value="Farming">Farming</option>Funeral Service
<option value="Funeral ">Funeral Service</option>
<option value="Law ">Law</option>
<option value="Auto">Auto Dealers</option>
<option value="Medicine">Medicine</option>
</select>
                                            </div>
                                        </div>
										</div>
									 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> Specialisation:</label>
                                                <input type="text" style="color: black" name="sp" id="sp" class="form-control" placeholder="Specialty" value="<?php echo $sp ; ?>">
                                            </div>
                                        </div>
                                    </div>
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Work Permit:</label>
												<select name="Permit" style="color: black" id="Permit" class="form-control">
												<option selected="selected" value="<?php echo $Permit ;?>"><?php echo $Permit ;?></option>
                                                <option value="Yes">Yes</option>
  													<option value="No">No</option>
													</select>
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Qualifications Obtained:</label>
                                                <textarea rows="4" name="Q" id="Q" cols="80" style="color: black" class="form-control" placeholder="Qualifications" ><?php echo $Highest_Q; ?>  </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
					 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <input type="submit" class="form-control" value="Save " style="background-color: #0066FF" >
                                            </div>
                                        </div>
                              		</div>
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
