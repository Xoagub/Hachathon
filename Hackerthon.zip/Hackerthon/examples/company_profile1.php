
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Company_Profile"; // Table name 

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Name1=$_POST["Name"]; 
$Address=$_POST["Address"];
$email1=$_POST["email"]; 
$Headquarters=$_POST["Headquarters"];
$Website=$_POST["Website"]; 
$Contact=$_POST["Contact"];
$Industry=$_POST["Industry"]; 
$City1=$_POST["City"];
$Po1=$_POST["Po"]; 
$Country1=$_POST["Country"];
$Zip=$_POST["Zip"]; 
$About=$_POST["About"];



$fql=("UPDATE $tbll_name SET Street_Adress='".$Address."', Email= '".$email1."', headquearters = '".$Headquarters."', Website = '".$Website."', Telephone = '".$Contact."', Industry = '".$Industry."', City = '".$City1."', Country = '".$Country1."', 	Postal_Address = '".$Po1."', Zip_Code = '".$Zip."', About_Company = '".$About."', Company = '".$Name1."' WHERE Email = '".$company."' ");


setcookie("user", $myusername, time()+3600000); 
setcookie("company", $Name1, time()+3600000); 
	
if (!mysqli_query($link,$fql))
  {  
  header("location: company_profile.php");

  }

header("location: company_profile.php");
	
	
	
	  ?>
 


