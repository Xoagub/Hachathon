<?php
	
$user = $_COOKIE["user"];
$company = $_COOKIE["company"];



$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Company_Profile"; // Table name 
			
$db_name="motleesy_namtax"; // Table name 

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	$Street_Adress = $row["Street_Adress"];
    $headquearters = $row["headquearters"];
	$Website = $row["Website"];
	
	$Telephone = $row["Telephone"];
    $Industry = $row["Industry"];
	$City = $row["City"];
	
	$Country = $row["Country"];
    $Postal_Address = $row["Postal_Address"];
	$Zip_Code = $row["Zip_Code"];
	
	$About_Company = $row["About_Company"];
    $Company = $row["Company"];
	
    
	
?>