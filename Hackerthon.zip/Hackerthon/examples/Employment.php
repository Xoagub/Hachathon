 
 <?php
	  
	  include('Employment1.php');
	
	  ?>


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                       <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				 <h7 class="title"> <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div></h7>
</div>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">   <li>
                        <a href="dashboard.php">
                       
                            <p>Dashboard</p>
                        </a>
                    </li><li>
                        <a href="apply.php">
                            <i class=""></i> <p>Vacancies</p>     </a></li>
                
                 
             
                    <li>
                        <a href="user.php">
                           
                           <p>Profile</p>
                        </a>
                    </li>
                   
                     <li>
                        <a href="Education.php">
                  
                            <p>Education</p>
                        </a>
                    </li>
                     
                     <li class="active">
                        <a href="Employment.php">
                           
                            <p>Employment History </p>
                        </a>
                    </li>
                      <li>
                        <a href="reference.php">
                           
                            <p>References</p>
                        </a>
                    </li><li>
                        <a href="log_Off.php">
                          
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Employment History</h5>
                            </div>
                            <div class="card-body">
                                <form action="Employment_edit.php" method="post">
                                   <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Experience: </label>
                                                <?php echo $Years ; ?>
                                            </div>
                                        </div>
										</div>
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Supervisory Years Experience: </label>
                                               <?php echo $Years1 ; ?>
                                            </div>
                                        </div>
										</div>
										<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Employment Status:</label>
                                               <?php echo $status ;?>
                                            </div>
                                        </div>
										</div>
										
										<?php 
										
										if($Company1 != "")
										
										{
										?>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Company: </label>
                                                <?php echo $Company1 ; ?>
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Employed: </label>
                                               <?php echo $Years_employed1 ; ?>
                                            </div>
                                        </div>
										</div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Position:</label>
                                               <?php echo $Position1 ; ?>
                                            </div>
                                        </div>                                      
                                       
                                    </div>
									<?php
									
									}
									?>
									<?php 
										
										if($Company2 != "")
										
										{
										?>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Company: </label>
                                                <?php echo $Company2 ; ?>
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Employed: </label>
                                               <?php echo $Years_employed2 ; ?>
                                            </div>
                                        </div>
										</div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Position:</label>
                                               <?php echo $Position2 ; ?>
                                            </div>
                                        </div>                                      
                                       
                                    </div>
									<?php
									
									}
									?>
									<?php 
										
										if($Company3 != "")
										
										{
										?>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Company: </label>
                                                <?php echo $Company3 ; ?>
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Employed: </label>
                                               <?php echo $Years_employed3 ; ?>
                                            </div>
                                        </div>
										</div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Position:</label>
                                               <?php echo $Position3 ; ?>
                                            </div>
                                        </div>                                      
                                       
                                    </div>
									<?php
									
									}
									?>
									<?php 
										
										if($Company4 != "")
										
										{
										?>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Company: </label>
                                                <?php echo $Company4 ; ?>
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Employed: </label>
                                               <?php echo $Years_employed4 ; ?>
                                            </div>
                                        </div>
										</div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Position:</label>
                                               <?php echo $Position4 ; ?>
                                            </div>
                                        </div>                                      
                                       
                                    </div>
									<?php
									
									}
									?>
									<?php 
										
										if($Company5 != "")
										
										{
										?>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Company: </label>
                                                <?php echo $Company5 ; ?>
                                            </div>
                                        </div>
										</div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years Employed: </label>
                                               <?php echo $Years_employed5 ; ?>
                                            </div>
                                        </div>
										</div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Position:</label>
                                               <?php echo $Position5 ; ?>
                                            </div>
                                        </div>                                      
                                       
                                    </div>
									<?php
									
									}
									?>
                                    
                   
                                    
                                    
                                    
                                    
                                         
                                    
                                    
                         
                                    
                                   <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <input type="submit" class="form-control" value="Edit" style="background-color: #0066FF" >
                                            </div>
                                        </div>
                              		</div>
                                   
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
