 <?php
	  
	  include('company2.php');
	  
	  
// get supervisor email
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbl_name="Load_Vacancy"; // Table name 
$tbl1_name="Load_Vacancy";
$db_name="motleesy_namtax"; // Table name 
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB"); 




$today = date("Y-m-d");


$cow = "Paid";

$query = "SELECT * FROM $tbl_name WHERE Closing_Date >= '".$today."' AND Paid= '".$cow."' "; //Write a query


$data = mysqli_query($link, $query);  //Execute the query
$num = mysqli_num_fields($link, $query);

$result33 = $link->query($query);
if ($result33->num_rows > 0) {
    // output data of each row
    while($row = $result33->fetch_assoc()) {
	$fr = $row['ID'];	
   	$Views2 = $row['Views'];
   
	$Views2 = $Views2 + 1 ;
	
				
	
$bql=("UPDATE $tbl_name SET Views = '".$Views2."'  WHERE ID = '".$fr."' ");

		if (!mysqli_query($link,$bql))
  {
  die('Error: ' . mysqli_error($link));
  }
		
	}
}

?>
	<?php
  $dir = 'img/';
  // Initiate array which will contain the image name
  $imgs_arr = array();
  // Check if image directory exists
  if (file_exists($dir) && is_dir($dir) ) {
    
      // Get files from the directory
      $dir_arr = scandir($dir);
      $arr_files = array_diff($dir_arr, array('.','..') );
      foreach ($arr_files as $file) {
        //Get the file path
        $file_path = $dir."/".$file;
        // Get extension
        $ext = pathinfo($file_path, PATHINFO_EXTENSION);
        if ($ext=="jpg" || $ext=="png" || $ext=="JPG" || $ext=="PNG" || $ext=="JPG" ) {
          array_push($imgs_arr, $file);
        }
        
      }
      $count_img_index = count($imgs_arr) - 1;
      $random_img = $imgs_arr[rand( 0, $count_img_index )];
  }
?>




<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
	<style>

		
		</style>
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                       <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				  <h7 class="title"> <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$data2 = ".jpg";
$result = $company . $data2;

$result6 = glob("../examples/company_upload/$company3.*");

$data3 = ".pdf";
$result1 = $company . $data3;


$me = $_COOKIE["company"];



?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div></h7>
</div>
            </div>
            <div class="sidebar-wrapper">
                            <ul class="nav">  		  <li >
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="dashboard.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Ratings</p>
                        </a>
                    </li>
					
					 <li class="active">
                        <a href="apply2.php">
                            <i class="now-ui-icons education_hat"></i> <p>View Gigs</p>     </a></li>
                
                
                   <li class="">
                        <a href="apply.php">
                            <i class="now-ui-icons education_hat"></i> <p>Post Gig</p>     </a></li>
                        
                           <li class="">
                        <a href="service.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Service Provider</p>
                        </a>
                    </li>
                    <li>
                        <a href="log_Off.php">
                              <i class="now-ui-icons sport_user-run"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel" >
            <!-- Navbar -->
           <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid" >
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler" style="background-color: #0033FF">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                     
                    </div>
                   
                  
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">View Gig</h5>
                            </div>
                            
                               <form action="views.php" method="post">
                                                                        
                          
                                    
								
                                  <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Looking for </label>
                                              
												<select name="Country" id="Country" style="color: black" class="form-control">
													<option>Accommodation</option>
												<option>Accounting</option>
                                              <option>Advertising</option>
                                              <option>Agriculture</option>
											        <option>Airtime and Electricity</option>
                                              <option>
Cleaning and Hygiene Products</option>
                                              <option>Business Consulting</option>
											        <option>Car Washing and Detailing</option>
                                              <option>Catering</option>
                                              <option>Construction </option>
											        <option>Copywriting</option>
                                              <option>Digital Marketing</option>
                                              <option>Educational Materials</option>
											        <option>Engineer</option>
                                              <option>Electrician</option>
                                              <option>Errand </option>
											        <option>Event Planning</option>
                                              <option>Fishing</option>
                                              <option>Food Delivery</option>
													 <option>Food Service</option>
											        <option>Financial Services</option>
													   <option>Fuel Supply</option>
											        <option>Funeral Services</option>
													<option>Graphic Design</option>
                                              <option>Hair Styling</option>
                                              <option>Handyman </option>
											            <option>Health and Social Work</option>
                                              <option>Home Cleaning</option>
                                              <option>Home Inspecting</option>
											        <option>Home Staging</option>
                                              <option>House Painting</option>
                                              <option>House Sitting </option>
											        <option>Information, Technology and Communication</option>
                                              <option>Landscaping</option>
                                              <option>Lawyer/Legal </option>
											        <option>Lead Generating</option>
                                              <option>Life Coaching</option>
                                              <option>Locksmith</option>
											        <option>Makeup Assistance</option>
													   <option>Marketing</option>
                                              <option>Massage Therapy</option>
                                              <option>Mobile App Development </option>
											        <option>Moving Assistance</option>
                                              <option>Personal Chef</option>
                                              <option>Pet Grooming</option>
											        <option>Photography</option>
                                              <option>Printing</option>
                                              <option>Research </option>
											  
											         <option>Resume Assistance</option>
													<option>Safety and security</option>
													<option>Scientific Services</option>
                                              <option>Shopping Assistance</option>
											        <option>Software Development</option>
                                              <option>Tailoring and Alterations</option>
                                              <option>Translation </option>
											        <option>Transportation</option>
                                              <option>Tutoring</option>
                                              <option>Valet</option>
													<option>Vehicle Repair</option>
											        <option>Videography</option>
                                              <option>Virtual Assistant</option>
													 <option>Water Supply</option>
                                              <option>Web Design </option>
													<option>Wholesale and Retail Trade </option>
 </select>
                                            </div>
                                        </div>
										</div>                                            
                                              <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Date wanted</label>
                                                <input type="date" name="Age" id="Age" style="color: black" class="form-control" placeholder="Age" value="<?php echo $Age ; ?>" >
                                            </div>
                                        </div>
                                    </div>    
                 
					 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <input type="submit" class="form-control" value="View" style="background-color: #0066FF" ><input class="form-control" type="button" value="View All Gigs" style="background-color: #0066FF" onclick="window.location.href='viewa.php'" />
                                            </div>
                                        </div>
                              		</div>
					
							
                                             						
                                           
                                          
                                       
                                     
                                 
                                 
                                  
                                 
                                    
                                     
                                    
                              
                                </form>
                            
                        
                  
							</div>
				
					
			</div>					
						
        </div>
                </div>

            </div>


            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
