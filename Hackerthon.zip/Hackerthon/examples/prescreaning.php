<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
           <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				
				 <h7 class="title"> 
				 <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

	
$data2 = ".jpg";
$result = $company . $data2;

$result6 = glob("../examples/company_upload/$company3.*");

$data3 = ".pdf";
$result1 = $company . $data3;

if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

echo  " $me " ; $company = $_COOKIE["user"];

// get supervisor email
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 

$tbl1_name="Load_Vacancy";
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB"); 



$active ="active";


$query = "SELECT * FROM $tbl1_name  WHERE Company = '$company3'  
 "; //Write a query
$data = mysqli_query($link, $query);  //Execute the query
$num = mysqli_num_fields($link, $query);

?></h7></div>
            </div>
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li>  <a href="dashboardc.php">
                            
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                        
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li>
                        <a href="Load_Vacancy.php">
                           
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li  class="active">
                        <a href="prescreaning.php">
                 
                            <p>Prescreening question </p>
                        </a>
                    </li>
                     <li> <a href="History.php">
                   
                            <p>Pre-Screening History</p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
         <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Pre Screening</h5>
                            </div>
                            <div class="card-body">
                                <form action="prescreaning1.php" method="post">
                                                                       
                                     <div class="row">
                                        <div class="col-md-12">
                                           
                                                <div class="form-group">
                                                <label>Position</label>
                                                <select name="Position" id="Position" style="color:black" class="form-control">
                                             												<?php
									while($fetch_options = mysqli_fetch_array($data)) { //Loop all the options retrieved from the query
									?>
											 //Added Id for Options Element 
												<option value="<?php echo $fetch_options['ID']; 	 ?>" onClick=""><?php echo 	$fetch_options['ID']; echo " ";  echo 	$fetch_options['Position']; ?></option><!--Echo out options-->

												<?php
											}
											?>
											
												 </select>
                                            </div>
										</div>
									</div>
                                                <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years of Experience</label>
                                                <select name="Years" id="Years" style="color:black" class="form-control">
  													<option value="1">1</option>
 													 <option value="2">2</option>
  													 <option value="3">3</option>
  													 <option value="4">4</option>
 													 <option value="5">5</option>
  													 <option value="6">6</option>
  													 <option value="7">7</option>
 													 <option value="8">8</option>
  													 <option value="9">9</option>
  													 <option value="10">10</option>
 													 <option value="11">11</option>
  													 <option value="12">12</option>
  													 <option value="13">13</option>
 													 <option value="14">14</option>
  													 <option value="15">15</option>
  													 <option value="15">16</option>
 													 <option value="17">17</option>
  													 <option value="18">18</option>
  													 <option value="19">19</option>
 													 <option value="20">20</option>
  													 <option value="21">21</option>
  													 <option value="22">22</option>
 													 <option value="23">23</option>
  													 <option value="24">24</option>
  													 <option value="25">25</option>
 													 <option value="26">26</option>
  													 <option value="27">27</option>
  													 <option value="28">28</option>
 													 <option value="29">29</option>
  													 <option value="30">30</option>
												 </select>
                                            </div>
                                        </div>
                                        </div>
                                      
                                        <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Years_iportance" id="Years_iportance" style="color:black" class="form-control">
  													<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
                                            </div>
                                        </div>
                                     
                                    </div>
                                     
                              
								
                                         <div class="row">
                                        <div class="col-md-12">
                                        <div class="form-group">
                                                <label>Qualification</label>
                                                <select name="Qualification" id="Qualification" style="color:black" class="form-control">
                                                	<option value="1">Grade 10</option>
                                                	<option value="2">Grade 12</option>
  													<option value="1">Certificate</option>
 													 <option value="3">Bachelor</option>
  													 <option value="4">Honors</option>
  													 <option value="5">Masters</option>
 													 <option value="6">PHD</option>
  													 
  													 
 													
												 </select>
                                            </div>
											 </div>
                                           </div>
										   
										     <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Qualification_i" style="color:black" id="Qualification_i" class="form-control">
  															<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
                                          </div>
								</div>
                                          </div>
                                           
                                            <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Namibian Citizen</label>
                                                <select name="Namibian" style="color:black" id="Namibian" class="form-control">
                                                	<option value="Yes">Yes</option>
                                                	<option value="No">No</option>
  													<option value="Maybe">Maybe</option>	
												 </select>
                                            </div>
                                            </div>
                                            </div>
											
											  <div class="row">
                                        <div class="col-md-12">
                                              <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Namibian_i" style="color:black" id="Namibian_i" class="form-control">
  														<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
                                          </div>
												</div> 
											</div>
                                                  
                                                      <div class="row"> 
                                        <div class="col-md-12">
                                                    
                                             <div class="form-group">
                                                <label>Work Permit</label>
                                                <select name="Permit" style="color:black" id="Permit" class="form-control">
                                                	<option value="Yes">Yes</option>
                                                	<option value="No">No</option>
  													</select>
                                            </div>
										 </div>
										 </div>
                                           
										     <div class="row">
                                        <div class="col-md-12">
                                                <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Permit_i" style="color:black" id="Permit_i" class="form-control">
  															<option value="1">Important</option>
 													 <option value="0">Not Important</option>
												 </select>
                                          </div>
                                            
						</div></div>
													  <div class="row">
                                        <div class="col-md-12">
                                           				  <div class="form-group">
                                                <label>Currently Employed</label>
                                                <select name="Employed" style="color:black" id="Employed" class="form-control">
                                                	  <option value="Employed">Employed</option>
  													<option value="Not_Employed">Not Employed</option>
  														
												 </select>
                                            </div>
														</div>
                                            </div>
                                            
											  <div class="row">
                                        <div class="col-md-12">
                                                <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Employed_i" style="color:black" id="Employed_i" class="form-control">
  														<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
                                          </div>
								</div></div>
                                            	  <div class="row">
                                        <div class="col-md-12">
                                             <div class="form-group">
                                                <label>Valid Drivers License</label>
                                                <select name="Drivers" id="Drivers" style="color:black" class="form-control">
                                                <option value="1">A</option>
  													<option value="2">B</option>
													 <option value="3">BE</option>
  													<option value="4">C1</option>
													<option value="5">C</option>
													<option value="6">CE</option>	
												 </select>
                                            </div>
													</div></div>
													
													  <div class="row">
                                        <div class="col-md-12">
                                           	<div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Drivers_i" id="Drivers_i" style="color:black" class="form-control">
  														<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
													</div>
								</div></div>
                                            	  <div class="row">
                                        <div class="col-md-12">
                                             <div class="form-group">
                                                <label>Proficient in English </label>
                                                <select name="English" id="English" style="color:black" class="form-control">
                                                 <option value="3">Good</option>
  													<option value="2">Fair</option>
													<option value="1">Weak</option>	
												 </select>
                                            </div>
													</div></div>
													
													  <div class="row">
                                        <div class="col-md-12">
                                           	<div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="English_i" style="color:black" id="English_i" class="form-control">
  															<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
													</div>
								</div></div>
                                            	  <div class="row">
                                        <div class="col-md-12">
                                             <div class="form-group">
                                                <label>Access on Transport</label>
                                                <select name="Transport" style="color:black" id="Transport" class="form-control">
                                                 <option value="Yes">Yes</option>
  													<option value="No">No</option>	
												 </select>
                                            </div>
                                                   </div>                                
                                            </div>
											
											  <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Transport_i" style="color:black" id="Transport_i" class="form-control">
  														<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
													</div>
								</div></div>
                                            	  <div class="row">
                                        <div class="col-md-12">
                                             <div class="form-group">
                                                <label>Minimum Managerial/Supervisory Experience </label>
                                                <select name="Supervisory_Experience" style="color:black" id="Supervisory_Experience" class="form-control">
                                                	<option value="0">0</option>
                                                	<option value="1">1</option>
 													 <option value="2">2</option>
  													 <option value="3">3</option>
  													 <option value="4">4</option>
 													 <option value="5">5</option>
  													 <option value="6">6</option>
  													 <option value="7">7</option>
 													 <option value="8">8</option>
  													 <option value="9">9</option>
  													 <option value="10">10</option>
 													 <option value="11">11</option>
  													 <option value="12">12</option>
  													 <option value="13">13</option>
 													 <option value="14">14</option>
  													 <option value="15">15</option>
  													 <option value="15">16</option>
 													 <option value="17">17</option>
  													 <option value="18">18</option>
  													 <option value="19">19</option>
 													 <option value="20">20</option>
  													 <option value="21">21</option>
  													 <option value="22">22</option>
 													 <option value="23">23</option>
  													 <option value="24">24</option>
  													 <option value="25">25</option>
 													 <option value="26">26</option>
  													 <option value="27">27</option>
  													 <option value="28">28</option>
 													 <option value="29">29</option>
  													 <option value="30">30</option>
												 </select>
                                            </div>
													</div></div>
													  <div class="row">
                                        <div class="col-md-12">
                                           <div class="form-group">
                                                <label>Importance To Vacant Post</label>
                                                <select name="Supervisory_Experience_i" style="color:black" id="Supervisory_Experience_i" class="form-control">
  															<option value="1">Important</option>
 													 <option value="0">Not Important</option>
  													
												 </select>
													</div>
								</div></div>
							
                                             <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                  <input type="submit" style="color:blue" class="form-control" value="Add/Amend Screen Criteria" >
                                 			
												
												 
                                            </div>
                                        </div>
                                       </div>
                                     
                                 
                                 
                                  
                                 
                                    
                                     
                                    
                              
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
