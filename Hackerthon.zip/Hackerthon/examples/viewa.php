

<?php





  $dir = 'img/';
  // Initiate array which will contain the image name
  $imgs_arr = array();
  // Check if image directory exists
  if (file_exists($dir) && is_dir($dir) ) {
    
      // Get files from the directory
      $dir_arr = scandir($dir);
      $arr_files = array_diff($dir_arr, array('.','..') );
      foreach ($arr_files as $file) {
        //Get the file path
        $file_path = $dir."/".$file;
        // Get extension
        $ext = pathinfo($file_path, PATHINFO_EXTENSION);
        if ($ext=="jpg" || $ext=="png" || $ext=="JPG" || $ext=="PNG") {
          array_push($imgs_arr, $file);
        }
        
      }
      $count_img_index = count($imgs_arr) - 1;
      $random_img = $imgs_arr[rand( 0, $count_img_index )];
  }
?>

<?php 



$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password 
$db_name="Hack"; // Database name 

$tbl1_name="gig";
$tbl2_name="Company_Profile";
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB"); 

$clear = "clear";


$active ="active";

$cow = "Paid";

$query = "SELECT * FROM $tbl1_name   ORDER BY ID DESC
 "; //Write a query




$data = mysqli_query($link, $query);  //Execute the query
$num = mysqli_num_fields($link, $query);

?>


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"><link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>

<style >
p.thicker {
  font-weight: 900;
}</style>
	
<meta name="robots" content="noindex,follow" />
<script>
function myFunction() {
  alert("To view advance data analytics click on position!");
}
</script>
		
</head>

<body class="" >
    <div class="wrapper ">
        <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				 <h7 class="title"> <?php

$company1 = $_COOKIE["user"];



$me = $_COOKIE["company"];


$tbll_name="Apply"; // Table name 
$tbl2_name="Load_Vacancy"; // Table name
$tb3_name="video"; // Table name
	   
	   $tb4_name="Pictures_c"; // Table name

// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 

	   
	   
	   
	   $pqr="SELECT * FROM $tb4_name WHERE user = '".$company1."' ORDER BY id DESC limit 1 ";


    // output data of each row
	$result89 = mysqli_query($link, $pqr);
    $row4 = mysqli_fetch_array($result89, MYSQLI_BOTH);

	
	$me444 = $row4["name"];	
	   
	   $me544 = ".";
	  $ve4 = $me544 . $me444 ;
	   
	 
	 $cat4 = $me1 . $ve4 ;
					 
?><div style="color: white"><?php echo  "  $Surname1 " ; ?></div> 
</h7>
</div>
            </div>
         
            <div class="sidebar-wrapper">
       <ul class="nav">    
                   <li >
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="dashboard.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Ratings</p>
                        </a>
                    </li>
					
					 <li class="active">
                        <a href="apply2.php">
                            <i class="now-ui-icons education_hat"></i> <p>View Gigs</p>     </a></li>
                
                
                   <li class="">
                        <a href="apply.php">
                            <i class="now-ui-icons education_hat"></i> <p>Post Gig</p>     </a></li>
                        
                           <li class="">
                        <a href="service.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Service Provider</p>
                        </a>
                    </li>
                    <li>
                        <a href="log_Off.php">
                              <i class="now-ui-icons sport_user-run"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
              <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid" >
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler" style="background-color: #0033FF">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                     
                    </div>
                   
                  
                </div>
            </nav>
            <!-- End Navbar -->
           <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <!-- End Navbar -->
          
			<div class="slideshow-container">


<div>

</div>


</div>

						     
            <div class="content">
            		<?php
while($fetch_options = mysqli_fetch_array($data)) { ?>				  
                <div class="row">
               
                  <div class="col-md-10">
                      <div class="card">
                        <div class="card-header">
							<h5 class="card-category">All Gigs</h5>
							<div align="right"><a href="bid.php?boom=<?php echo $fetch_options['ID']; ?>&boom1=<?php echo $fetch_options['user']; ?>" style="color: #0E46F9"><strong>Bid </strong> </a></div>
						 <h5 class="title" align="center"><?php echo $fetch_options['Position'];?></h5> 
                          </div>

                        <div class="card-body">
                            

                                   
   <?php                                    
                                      
 //Loop all the options retrieved from the query

$cat = $fetch_options['User']; 
$id = $fetch_options['ID']; 
	
$cow = "Interview";

$cancel = "Unsuccesfull";

$query33 = "SELECT * FROM $tbll_name  WHERE Application_ID = '$id' AND Interview = '".$cow."'  ";


	$result1=mysqli_query($link, $query33);

// Mysql_num_row is counting table row
$count34=mysqli_num_rows($result1);

$query34 = "SELECT * FROM $tbll_name  WHERE Application_ID = '$id' AND Interview = '".$cancel."'  ";


	$result2=mysqli_query($link, $query34);

// Mysql_num_row is counting table row
$count35=mysqli_num_rows($result2);



$totale = $count34 + $count35 ;

?> <img src="view.png" width="70" height="70"> <strong> Gig Name : <?php echo $fetch_options['Name']; ?></strong>    &nbsp; &nbsp; &nbsp; &nbsp; <img src="success.png" width="70" height="70"> <strong> Description : <?php echo  $fetch_options['Description']; ?></strong> <br><br>
<img src="total.png" width="70" height="70"><strong>Wanted Date : <?php echo $fetch_options['wanted']; ?>  &nbsp; &nbsp; &nbsp; &nbsp; <img src="success.png" width="70" height="70"> <strong> Price : <?php echo  $fetch_options['Price']; ?></strong></strong>
							
							

				
                        </div>
                      </div>
 

  </div>
  </div>
				
	  <?php    }
?>  
		
   
	</div>

		
			
	
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
							</li>
                            
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Recruitment
                        
                    </div>
                </div>
            </footer>
      
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="js/jquery.nivo.slider.pack.js"></script>
<script>
	$(window).load(function() {
		$('#slider').nivoSlider({
			effect: 'random',
			directionNavHide: false,
			pauseOnHover: true,
			captionOpacity: 1,
			prevText: '<',
			nextText: '>'
		});
	});
</script>

</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>