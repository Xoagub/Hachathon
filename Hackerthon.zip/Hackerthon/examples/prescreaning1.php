<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
          <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				
				 <h7 class="title"> 
				 <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

	
$data2 = ".jpg";
$result = $company . $data2;

$result6 = glob("../examples/company_upload/$company3.*");

$data3 = ".pdf";
$result1 = $company . $data3;

if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

echo  " $me " ; $company = $_COOKIE["user"];



?></h7></div>
            </div>
            
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li >  <a href="dashboardc.php">
                        
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                        
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li>
                        <a href="Load_Vacancy.php">
                          
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li class="active">
                        <a href="prescreaning.php">
                        
                            <p>Prescreening question </p>
                        </a>
                    </li>
                     <li> <a href="History.php"> <p>Pre-Screening </p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
           <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Pre Screening</h5>
                            </div>
                            <div class="card-body">
 <?php
	  
	  $company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Pre_Screening";
$tbl2_name="Apply"; // Table name 
$tbl4_name="Employement_History"; // Table name 
$tbl7_name="Tertiary"; // Table name 

$tbl3_name="User_Profile"; 
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
$Position=$_POST["Position"]; 
$Years=$_POST["Years"];
$Years_iportance=$_POST["Years_iportance"]; 
$Qualification=$_POST["Qualification"];
$Qualification_i=$_POST["Qualification_i"]; 
$Namibian=$_POST["Namibian"];
$Namibian_i=$_POST["Namibian_i"]; 
$Permit=$_POST["Permit"];
$Permit_i=$_POST["Permit_i"]; 
$Employed=$_POST["Employed"];
$Employed_i=$_POST["Employed_i"]; 
$Drivers=$_POST["Drivers"];
$Drivers_i=$_POST["Drivers_i"]; 
$English=$_POST["English"];
$English_i=$_POST["English_i"]; 
$Transport=$_POST["Transport"];
$Transport_i=$_POST["Transport_i"]; 

$Supervisory_Experience=$_POST["Supervisory_Experience"];
$Supervisory_Experience_i=$_POST["Supervisory_Experience_i"]; 


	$wql="SELECT * FROM $tbll_name WHERE Company = '".$company."' AND Position = '".$Position."'	 ";

$details = mysqli_fetch_array($result2, MYSQLI_BOTH);

$result=mysqli_query($link, $wql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);


// look if any applicants
	$tql="SELECT * FROM $tbl2_name WHERE Application_ID = '".$Position."'	 ";

$details = mysqli_fetch_array($result2, MYSQLI_BOTH);

$result4=mysqli_query($link, $tql);

// Mysql_num_row is counting table row
$count4=mysqli_num_rows($result4);

if($count4 < 1 )
{
echo "No Applicants";
}


$hg = 0;

// If result matched $myusername and $mypassword, table row must be 1 row
if($count = $hg ){

	$sql="INSERT INTO $tbll_name (Company, Position, Years_Experince, Years_Importance, Qualification, Qualifications_Importance, Nationality, Nationality_Importance, Work_Permit, Permit_Importance, Employed, 	Employed_Importance, Drivers_License, Drivers_Importance, Proficience, Proficiency_Importance,  Access_Transport, Transport_Importance, Supervisor_Role, Supervisor_Importance)
VALUES
( '$company', '$Position', '$Years', '$Years_iportance', '$Qualification', '$Qualification_i', '$Namibian', '$Namibian_i', '$Permit', '$Permit_i', '$Employed', '$Employed_i', 'Drivers', '$Drivers_i', '$English',  '$English_i', '$Transport', '$Transport_i', '$Supervisory_Experience', '$Supervisory_Experience_i'  )";

if (!mysqli_query($link,$sql))
  {
  die('Error: ' . mysqli_error($link));
  }
 
 
 $pql = "SELECT * FROM $tbl2_name WHERE Application_ID ='$Position' ";
$result9 = $link->query($pql);
if ($result9->num_rows > 0) {
    // output data of each row
    while($row = $result9->fetch_assoc()) {
   	$User = $row["User"];

$oql = "SELECT * FROM $tbl3_name WHERE Email='$User' ";
$result2 = $link->query($oql);

    // output data of each row
	$result2 = mysqli_query($link, $oql);
    $row = mysqli_fetch_array($result2, MYSQLI_BOTH);
    $drivers1 = $row["Drivers"];		 	
	 $Own_Car  = $row["Own_Car "];	
	  $English1 = $row["English"];	
	   $Permit44 = $row["Permit"];
	   $Country = $row["Country"];	
	   
	$uql = "SELECT * FROM $tbl4_name WHERE Email='$User' ";
$result3 = $link->query($uql);

    // output data of each row
	$result3 = mysqli_query($link, $uql);
    $row2 = mysqli_fetch_array($result3, MYSQLI_BOTH);
    $Working_Experience = $row2["Working_Experience"];
	$Supervisory_Years = $row2["Supervisory_Years"];
	$Employement_status = $row2["Employement_status"];


  
	$mql = "SELECT * FROM $tbl7_name WHERE Email='$User' ";
$result4 = $link->query($mql);

    // output data of each row
	$result4 = mysqli_query($link, $mql);
    $row4 = mysqli_fetch_array($result4, MYSQLI_BOTH);
    $Highest = $row4["Highest"];

	$one = 1;
	$zero = 0;
	// for experience 
	if($Years < $Working_Experience  AND $Years_iportance = $one ) 
	{
	$years_result = 1 ;
	
	}
	elseif( $Years < $Working_Experience Or $Years_iportance = $zero )
	{
	
	$years_result = 1 ;
	
	}
	else 
	{
	$years_result = 0 ;
	}

// for $Qualification
	if($Qualification < $Highest  AND $Qualification_i = $one ) 
	{
	$Qualification_result = 1 ;
	
	}
	elseif( $Qualification < $Highest OR $Years_iportance = $zero )
	{
	
	$Qualification_result = 1 ;
	
	}
	else 
	{
	$Qualification_result = 0 ;
	}
// for $Namibian_i
	if($Namibian = $Country  AND $Namibian_i = $one ) 
	{
	$Namibian_result = 1 ;
	

	}
	elseif( $Namibian = $Country  OR $Years_iportance = $zero )
	{
	
	$Namibian_result = 1 ;
	
	}
	else 
	{
	$Namibian_result = 0 ;
	}
	
	// for Permit
	if($Permit = $Permit44  AND $Permit_i = $one ) 
	{
	$Permit_result = 1 ;
	
	}
	elseif( $Namibian = $Permit44  OR $Permit_i = $zero )
	{
	
	$Permit_result = 1 ;
	
	}
	else 
	{
	$Permit_result = 0 ;
	}

	// for $Employed
	if($Employed = $Employement_status  AND $Employed_i = $one ) 
	{
	$Employed_result = 1 ;
	
	}
	elseif( $Employed = $Employement_status  OR $Employed_i = $zero )
	{
	
	$Employed_result = 1 ;
	
	}
	else 
	{
	$Employed_result = 0 ;
	}
	
		// for $Drivers
	if($Drivers <= $drivers1   AND $Drivers_i = $one ) 
	{
	$drivers1_result = 1 ;
	
	}
	elseif( $Drivers <= $drivers1  OR $Drivers_i = $zero )
	{
	
	$drivers1_result = 1 ;
	
	}
	else 
	{
	$drivers1_result = 0 ;
	}
	
	
	// for $English
	if($English <= $English1   AND $English1_i = $one ) 
	{
	$English_result = 1 ;
	
	}
	elseif( $English <= $English1 OR $English1_i = $zero )
	{
	
	$English_result = 1 ;
	
	}
	else 
	{
	$English_result = 0 ;
	}
	
		// for $Transport
	if($Transport = $Own_Car   AND $Transport_i = $one ) 
	{
	$Transport_result = 1 ;
	
	}
	elseif( $Transport = $Own_Car OR $Transport_i = $zero )
	{
	
	$Transport_result = 1 ;
	
	}
	else 
	{
	$Transport_result = 0 ;
	}
	
			// for $Supervisory_Experience
	if($Supervisory_Experience <= $Supervisory_Years   AND $Supervisory_Experience_i = $one ) 
	{
	$Supervisory_Experience_result = 1 ;
	
	}
	elseif( $Supervisory_Experience <= $Supervisory_Years OR $Supervisory_Experience_i = $zero )
	{
	
	$Supervisory_Experience_result = 1 ;
	
	}
	else 
	{
	$Supervisory_Experience_result= 0 ;
	}
	
	$totals = $years_result + $Qualification_result + $Namibian_result + $Permit_result + $Employed_result + $drivers1_result + $English_result + $Transport_result + $Supervisory_Experience_result ;
	
		$final_pc= (($totals/9) * 100);
		
		$mew = round($final_pc);
		
		$Interview = "Pre-Screened";
		
$fql=("UPDATE $tbl2_name SET Points= '".$mew."' , Working_Experience = '".$years_result."' , English= '".$English_result."' , Permit= '".$Permit_result."' , Qualification= '".$Qualification_result."' , Nationality= '".$Namibian_result."' , Employed_result= '".$Employed_result."' , Drivers= '".$drivers1_result."' , Own_Car= '".$Transport_result."' , Supervisory_Years= '".$Supervisory_Experience_result."' ,Interview = '".$Interview."'  WHERE User = '".$User."'  AND Application_ID = '".$Position."' ");

if (mysqli_query($link,$fql))
  {  
  
echo "Sucess";
  }
  



}
}

}

if($count = 1){



$fql=("UPDATE $tbll_name SET Company= '".$company."' , Position = '".$Position."' , Years_Experince= '".$Years."' , Years_Importance= '".$Years_iportance."' , Qualification= '".$Qualification."' , Qualifications_Importance= '".$Qualification_i."' , Nationality= '".$Namibian."' , Nationality_Importance= '".$Namibian_i."' , Work_Permit= '".$Permit."' , Permit_Importance= '".$Permit_i."' , Employed= '".$Employed."' , Employed_Importance= '".$Employed_i."' , Drivers_License= '".$Drivers."' , Drivers_Importance= '".$Drivers_i."' , Proficience= '".$English."' , Proficiency_Importance= '".$English_i."' , Access_Transport= '".$Transport."' , Transport_Importance= '".$Transport_i."' , Supervisor_Role= '".$Supervisory_Experience."' , Supervisor_Importance= '".$Supervisory_Experience_i."' WHERE Company = '".$company."' AND Position = '".$Position."' ");



 if (!mysqli_query($link,$fql))
  {
  die('Error: ' . mysqli_error($link));
  }
 
 $pql = "SELECT * FROM $tbl2_name WHERE Application_ID ='$Position' ";
$result9 = $link->query($pql);
if ($result9->num_rows > 0) {
    // output data of each row
    while($row = $result9->fetch_assoc()) {
   	$User = $row["User"];

$oql = "SELECT * FROM $tbl3_name WHERE Email='$User' ";
$result2 = $link->query($oql);

    // output data of each row
	$result2 = mysqli_query($link, $oql);
    $row = mysqli_fetch_array($result2, MYSQLI_BOTH);
    $drivers1 = $row["Drivers"];		 	
	 $Own_Car  = $row["Own_Car "];	
	  $English1 = $row["English"];	
	   $Permit44 = $row["Permit"];
	   $Country = $row["Country"];	
	   
	$uql = "SELECT * FROM $tbl4_name WHERE Email='$User' ";
$result3 = $link->query($uql);

    // output data of each row
	$result3 = mysqli_query($link, $uql);
    $row2 = mysqli_fetch_array($result3, MYSQLI_BOTH);
    $Working_Experience = $row2["Working_Experience"];
	$Supervisory_Years = $row2["Supervisory_Years"];
	$Employement_status = $row2["Employement_status"];


  
	$mql = "SELECT * FROM $tbl7_name WHERE Email='$User' ";
$result4 = $link->query($mql);

    // output data of each row
	$result4 = mysqli_query($link, $mql);
    $row4 = mysqli_fetch_array($result4, MYSQLI_BOTH);
    $Highest = $row4["Highest"];

	$one = 1;
	$zero = 0;
	// for experience 
	if($Years < $Working_Experience  AND $Years_iportance = $one ) 
	{
	$years_result = 1 ;
	
	}
	elseif( $Years < $Working_Experience Or $Years_iportance = $zero )
	{
	
	$years_result = 1 ;
	
	}
	else 
	{
	$years_result = 0 ;
	}

// for $Qualification
	if($Qualification < $Highest  AND $Qualification_i = $one ) 
	{
	$Qualification_result = 1 ;
	
	}
	elseif( $Qualification < $Highest OR $Years_iportance = $zero )
	{
	
	$Qualification_result = 1 ;
	
	}
	else 
	{
	$Qualification_result = 0 ;
	}
// for $Namibian_i
	if($Namibian = $Country  AND $Namibian_i = $one ) 
	{
	$Namibian_result = 1 ;
	

	}
	elseif( $Namibian = $Country  OR $Years_iportance = $zero )
	{
	
	$Namibian_result = 1 ;
	
	}
	else 
	{
	$Namibian_result = 0 ;
	}
	
	// for Permit
	if($Permit = $Permit44  AND $Permit_i = $one ) 
	{
	$Permit_result = 1 ;
	
	}
	elseif( $Namibian = $Permit44  OR $Permit_i = $zero )
	{
	
	$Permit_result = 1 ;
	
	}
	else 
	{
	$Permit_result = 0 ;
	}

	// for $Employed
	if($Employed = $Employement_status  AND $Employed_i = $one ) 
	{
	$Employed_result = 1 ;
	
	}
	elseif( $Employed = $Employement_status  OR $Employed_i = $zero )
	{
	
	$Employed_result = 1 ;
	
	}
	else 
	{
	$Employed_result = 0 ;
	}
	
		// for $Drivers
	if($Drivers <= $drivers1   AND $Drivers_i = $one ) 
	{
	$drivers1_result = 1 ;
	
	}
	elseif( $Drivers <= $drivers1  OR $Drivers_i = $zero )
	{
	
	$drivers1_result = 1 ;
	
	}
	else 
	{
	$drivers1_result = 0 ;
	}
	
	
	// for $English
	if($English <= $English1   AND $English1_i = $one ) 
	{
	$English_result = 1 ;
	
	}
	elseif( $English <= $English1 OR $English1_i = $zero )
	{
	
	$English_result = 1 ;
	
	}
	else 
	{
	$English_result = 0 ;
	}
	
		// for $Transport
	if($Transport = $Own_Car   AND $Transport_i = $one ) 
	{
	$Transport_result = 1 ;
	
	}
	elseif( $Transport = $Own_Car OR $Transport_i = $zero )
	{
	
	$Transport_result = 1 ;
	
	}
	else 
	{
	$Transport_result = 0 ;
	}
	
			// for $Supervisory_Experience
	if($Supervisory_Experience <= $Supervisory_Years   AND $Supervisory_Experience_i = $one ) 
	{
	$Supervisory_Experience_result = 1 ;
	
	}
	elseif( $Supervisory_Experience <= $Supervisory_Years OR $Supervisory_Experience_i = $zero )
	{
	
	$Supervisory_Experience_result = 1 ;
	
	}
	else 
	{
	$Supervisory_Experience_result= 0 ;
	}
	
	$totals = $years_result + $Qualification_result + $Namibian_result + $Permit_result + $Employed_result + $drivers1_result + $English_result + $Transport_result + $Supervisory_Experience_result ;
	
	$final_pc= (($totals/9) * 100);
	
		$mew = round($final_pc);
		
		$Interview = "Pre-Screened";

$kql=("UPDATE $tbl2_name SET Points= '".$mew."' , Working_Experience = '".$years_result."' , English= '".$English_result."' , Permit= '".$Permit_result."' , Qualification= '".$Qualification_result."' , Nationality= '".$Namibian_result."' , Employed_result= '".$Employed_result."' , Drivers= '".$drivers1_result."' , Own_Car= '".$Transport_result."' , Supervisory_Years= '".$Supervisory_Experience_result."', Interview = '".$Interview."'  WHERE User = '".$User."'  AND Application_ID = '".$Position."' ");

if (mysqli_query($link,$kql))
  {  
  
echo "Sucessfully Pre-Screened";
  }else
  {
  echo "No Applicants to Pre-screen";
  }
  
  }
  }




}






	
	  ?>
 
 </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>



