
<?php 


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tb1_name="User_Profile"; // Table name 


// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");


$email = $_POST["email"];
$firstName = $_POST["firstName"];
$password = $_POST["password"];


	//escapes special characters in a string
		
		$email = mysqli_real_escape_string($con,$email);
		
		$firstName = mysqli_real_escape_string($con,$firstName);
		
			
		$password = mysqli_real_escape_string($con,$password);
		
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    
} else {
    exit( "Email address $email is considered invalid.\n");
	}
		
				$rql="SELECT * FROM $tb1_name WHERE Email='".$email."' ";



$result=mysqli_query($con, $rql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count == 0){

		$hash = password_hash($password, PASSWORD_DEFAULT);

$sql="INSERT INTO $tb1_name (Name, Surname, Email, Password)
VALUES
( '$firstName', '$lastName', '$email', '$hash' )";


require('class.phpmailer.php');
require('class.smtp.php');
require('class.pop3.php');

require_once "PHPMailerAutoload.php";

//PHPMailer Object
$mail = new PHPMailer;

//From email address and name
$mail->From = "hr@motlee-systems.com";
$mail->FromName = "Motlee-Systems";

//To address and name
$mail->addAddress("$email", "$lastName");
$mail->addAddress("$email"); //Recipient name is optional

//Address to which recipient will reply
$mail->addReplyTo("reply@yourdomain.com", "Reply");


	
//Send HTML or Plain Text email
$mail->isHTML(true);

$mail->Subject = "Registration at Motlee Payroll Systems Details";
$mail->Body = "Dear $lastName, <br><br>
Welcome to the Motlee family.<br><br>
You have successfully registered to the Motlee HR Systems recruitment platform as a job seeker We look forward to easing your recruitment process!<br>
Below are your login credentials:<br><br>
Username: [$email]
Password: [$password]<br><br>
Please click on the link below to continue your job seeking process:<br> www.motlee-systems.com/Recruitment/login.html
<br><br>
Our system HR Platform also offers the following features:<br><br>
-	Payroll Administration <br>
-	Leave Management <br>
-	Performance Management <br>
-	Timesheets 
<br><br>
Please visit our website to find out more: www.motlee-systems.com  <br><br>
Motlee HR Systems
 .<br><br><br>Kind Regards<br><br>HR Team.
 ". date('Y-m-d H:i:s');
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
    
 setcookie("user", $email, time()+360000); 

header("location: examples/user.php");


}
else
{
$me = "Email already in use";
}		

		



?>

<!DOCTYPE HTML>
<html>
<head>
<title>Motlee E-Recruitment</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Motlee E-Recruitment" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 


<!----font-Awesome----->
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
	<div class="container">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
	        <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt=""/></a>
	    </div>
	    <!--/.navbar-header-->
	    <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" style="height: 1px;">
	        <ul class="nav navbar-nav">
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jobs<b class="caret"></b></a>
		            <ul class="dropdown-menu">
			            <li><a href="location.html">Category</a></li>
			            <li><a href="location.html">Location</a></li>
			         </ul>
		        </li>
		  
		       
		       
		        <li><a href="login.html">Login</a></li>
		       
	        </ul>
	    </div>
	    <div class="clearfix"> </div>
	  </div>
	    <!--/.navbar-collapse-->
	</nav>
<div class="banner_1">
	<div class="container">
		<div id="search_wrapper1">
		   <div id="search_form" class="clearfix">
		    <h1>Start your job search</h1>
		    <p>
			 <input type="text" class="text" placeholder=" " value="Enter Keyword(s)" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Enter Keyword(s)';}">
			 <input type="text" class="text" placeholder=" " value="Location" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Location';}">
			 <label class="btn2 btn-2 btn2-1b"><input type="submit" value="Find Jobs"></label>
			</p>
           </div>
		</div>
   </div> 
</div>	
<div class="container">
    <div class="single">  
	   <div class="form-container">
        <h2>Register Form</h2>
        <form name="registration" action="register2.php" method="post">
          <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="firstName">First Name</label>
                <div class="col-md-9">
                    <input type="text" path="firstName" id="firstName" class="form-control input-sm"  required/>
                </div>
            </div>
         </div>
         <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="lastName">Last Name</label>
                <div class="col-md-9">
                    <input type="text" path="lastName" id="lastName" class="form-control input-sm"  required/>
                </div>
            </div>
        </div>
       
           <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="email">Email</label>
                <div class="col-md-9">
                    <input type="text" path="email" id="email" class="form-control input-sm"  required/>
                </div>
            </div>
        </div>
		
		
        <div class="row">
            <div class="form-group col-md-12">
                <label class="col-md-3 control-lable" for="email">Password</label>
                <div class="col-md-9">
                    <input type="password" path="password" id="passowrd" class="form-control input-sm"  required/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-actions floatRight">
                <input type="submit" name="submit" value="Register" class="btn btn-primary btn-sm">
            </div>
        </div>
		
		<?php 


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tb1_name="User_Profile"; // Table name 


// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

$lastName = $_POST["lastName"];
$email = $_POST["email"];
$firstName = $_POST["firstName"];
$password = $_POST["password"];


		$lastName = mysqli_real_escape_string($con,$lastName); //escapes special characters in a string
		
		$email = mysqli_real_escape_string($con,$email);
		
		$firstName = mysqli_real_escape_string($con,$firstName);
		
			
		$password = mysqli_real_escape_string($con,$password);
		

    
 
				$rql="SELECT * FROM $tb1_name WHERE Email='".$email."' ";


$result=mysqli_query($con, $rql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count < 1){


		
require('class.phpmailer.php');
require('class.smtp.php');
require('class.pop3.php');

require_once "PHPMailerAutoload.php";

//PHPMailer Object
$mail = new PHPMailer;

//From email address and name
$mail->From = "hr@motlee-systems.com";
$mail->FromName = "Motlee-Systems";

//To address and name
$mail->addAddress("$email", "$lastName");
$mail->addAddress("$email"); //Recipient name is optional

//Address to which recipient will reply
$mail->addReplyTo("reply@yourdomain.com", "Reply");


	
//Send HTML or Plain Text email
$mail->isHTML(true);

$mail->Subject = "Registration at Motlee Payroll Systems Details";
$mail->Body = "Dear $lastName, <br><br>
Welcome to the Motlee family.<br><br>
You have successfully registered to the Motlee HR Systems recruitment platform as a job seeker We look forward to easing your recruitment process!<br>
Below are your login credentials:<br><br>
Username: [$email]
Password: [$password]<br><br>
Please click on the link below to continue your job seeking process:<br> www.motlee-systems.com/Recruitment/login.html
<br><br>
Our system HR Platform also offers the following features:<br><br>
-	Payroll Administration <br>
-	Leave Management <br>
-	Performance Management <br>
-	Timesheets 
<br><br>
Please visit our website to find out more: www.motlee-systems.com  <br><br>
Motlee HR Systems
 .<br><br><br>Kind Regards<br><br>HR Team.
 ". date('Y-m-d H:i:s');
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
		


		$hash = password_hash($password, PASSWORD_DEFAULT);

$sql="INSERT INTO $tb1_name (Name, Surname, Email, Password)
VALUES
( '$firstName', '$lastName', '$email', '$hash' )";

if (mysqli_query($con,$sql))
  {
   setcookie("user", $email, time()+360000); 

header("location: examples/user.php");
  }
  
 

  }


?>
    </form>
    </div>
 </div>
</div>
<div class="footer">
	<div class="container">

		<div class="col-md-3 grid_3">
			
		</div>
		<div class="col-md-3 grid_3">
			<h4>Sign up for our newsletter</h4>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam.</p>
			<form>
				<input type="text" class="form-control" placeholder="Enter your email">
				<button type="button" class="btn red">Subscribe now!</button>
		    </form>
		</div>
		<div class="clearfix"> </div>
	</div>
</div>
<div class="footer_bottom">	
  <div class="container">
    <div class="col-sm-2">
  		<ul class="f_list2">
			<li><a href="jobs.html">Namibian Jobs</a></li>
			
	    </ul>
  	</div>
  	<div class="col-sm-2">
  		<ul class="f_list2">
		
	    </ul>
  	</div>
  	<div class="col-sm-2">
  		<ul class="f_list2">
	
	    </ul>
  	</div>
  	<div class="col-sm-6 footer_text">
       <p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numqua"</p>
  	</div>
  	<div class="clearfix"> </div>
	<div class="copy">
		<p>Copyright © 2018 Motlee Systems . All Rights Reserved .</p>
	</div>
  </div>
</div>

</body>
</html>	