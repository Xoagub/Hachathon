


<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
	

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
<?php 
 // Require https
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
?>
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
           
             <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				
				 <h7 class="title"> 
				 <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

	
if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

echo  " $me " ; ?></h7></div>
            </div>
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li>  <a href="dashboardc.php">
                
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                       
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li  class="active">
                        <a href="Load_Vacancy.php">
                        
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li>
                        <a href="prescreaning.php">
                         
                            <p>Prescreening question </p>
                        </a>
                    </li>
                     <li> <a href="History.php"> <p>Pre-Screening </p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Load Vacancy</h5>
                            </div>
                            <div class="card-body">
                                <form action="Load_Vacancy2.php" method="post" > 
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Name Position </label>
                                                <input type="text" class="form-control"  placeholder="Name" id="Name" name="Name"  >
                                            </div>
                                        </div>
										</div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Number Vacancies </label>
                                                <input type="text" class="form-control" placeholder="Vacancies" id="Vacancies" name="Vacancy" >
                                            </div>
                                        </div>
										</div>
                                         <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Job Grade</label>
                                                <input type="text" class="form-control" placeholder="Job Grade" id="grade" name="grade"  >
                                            </div>
                                        </div>
										</div>
                                        
                                            <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Level of Operation </label>
                                                 <select name="Level" id="Level" class="form-control">
  													<option value="Junior">Junior/Support Person</option>
 													 <option value="Junior_Manager">Junior Manager</option>
  													 <option value="Middle_Manager">Middle Manager</option>
  													 <option value="Senior_Manager">Senior Manager</option>
 													 <option value="Executive">Executive</option>
  													
												 </select>
                                            </div>
                                        </div>
										</div>
                                        
                                          <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>New or Existing position </label>
                                                <input type="text" class="form-control" placeholder="" id="New_old" name="New_old" >
                                            </div>
                                        </div>
                                        </div>
										 <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Type Of Employement</label>
                                                 <select name="type" id="type" class="form-control">
  													<option value="Fulltime">Full time</option>
 													 <option value="Parttime">Part time</option>
  													 <option value="Internship">Internship</option>
  													 <option value="Contract">Contract</option>
 													
  													
												 </select>
                                            </div>
                                        </div>
										</div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Contact Person </label>
                                                <input type="text" class="form-control" placeholder="Surname" id="Person" name="Person" >
                                            </div>
                                        </div>
                                        </div>
                                         <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Contact Details</label>
                                                <input type="text" class="form-control" placeholder="Contact Details" id="Contact" name="Contact" >
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Years of Experience</label>
                                                <select name="Years" id="Years" class="form-control">
  													<option value="1">1</option>
 													 <option value="2">2</option>
  													 <option value="3">3</option>
  													 <option value="4">4</option>
 													 <option value="5">5</option>
  													 <option value="6">6</option>
  													 <option value="7">7</option>
 													 <option value="8">8</option>
  													 <option value="9">9</option>
  													 <option value="10">10</option>
 													 <option value="11">11</option>
  													 <option value="12">12</option>
  													 <option value="13">13</option>
 													 <option value="14">14</option>
  													 <option value="15">15</option>
  													 <option value="15">16</option>
 													 <option value="17">17</option>
  													 <option value="18">18</option>
  													 <option value="19">19</option>
 													 <option value="20">20</option>
  													 <option value="21">21</option>
  													 <option value="22">22</option>
 													 <option value="23">23</option>
  													 <option value="24">24</option>
  													 <option value="25">25</option>
 													 <option value="26">26</option>
  													 <option value="27">27</option>
  													 <option value="28">28</option>
 													 <option value="29">29</option>
  													 <option value="30">30</option>
												 </select>
                                            </div>
                                        </div>
                                     
                                    </div>
                                 
                                  
                                 
                                    
                                     
                                   <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Qualifications</label>
                                                <textarea rows="4" cols="80" class="form-control" placeholder="Here can be your description" name="Qualifications" id="Qualifications" > </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Skills requirement</label>
                                                <textarea rows="4" cols="80" class="form-control" placeholder="Here can be your description" name="Skills" id="Skills" > </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Job Description</label>
                                                <textarea rows="4" cols="80" class="form-control" placeholder="Here can be your description" name="Description" id="Description" > </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Role Requirements</label>
                                                <textarea rows="4" cols="80" class="form-control" placeholder="Here can be your description" name="Requirements" id="Requirements"  > </textarea>
                                            </div>
                                        </div>
                                    </div>
				   <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Closing Date </label>
                                                                                              <input class="form-control "name="Close" type="Date" />

                                            </div>
                                        </div>
					</div>
					
                                         <div class="row">
                                        <div class="col-md-5 pr-1">
                                            <div class="form-group">
                                                
                                 				 <input type="submit" class="form-control" value="Save " >
												<input type='submit' value='Amend Advert' class="form-control" style="text-align:left" onClick="form.action='Amend_Advert.php'; return true;">
                                            </div>
                                        </div>
                              		</div>
                                </form>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>