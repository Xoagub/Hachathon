<?php 

$Position=$_POST["Position"]; 
$Percentage=$_POST["Percentage"]; 
setcookie("cat1", $Percentage, time()+36000); 
setcookie("cat", $Position, time()+36000); 
header("location: History2.php");

?>