			     <?php
	
// set the expiration date to one hour ago
setcookie("company", "", time() - 3600);
setcookie("user", "", time() - 3600);

header("location: www.motlee-systems.com/Recruitment");

?>