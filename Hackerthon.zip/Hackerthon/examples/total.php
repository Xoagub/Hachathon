


<?php

$domain = "Botswana";

$company = $_COOKIE["user"];

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tb1_name="User_Profile"; // Table name 
$tb2_name="High_School";
$tb3_name="Tertiary";
$tb4_name="References";
$tb5_name="Past_Work";
$db_name="motleesy_namtax"; // Table name 

 // Table name


// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");

$sql = "SELECT * FROM $tb1_name WHERE Email='$company' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country3 = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$dog = $row["English"];
		$Permit = $row["Permit"];
    

$be = 0 ; 

if($Name != '')
{
	$be = $be +1;
}

if($Surname != '')
{
	$be = $be +1;
}

if($Cellphone != '')
{
	$be = $be +1;
}

if($Gender!= '')
{
	$be = $be +1;
}

if($Age != '')
{
	$be = $be +1;
}
if($Address != '')
{
	$be = $be +1;
}
if($City != '')
{
	$be = $be +1;
}

if($Country3 != '')
{
	$be = $be +1;
}

if($Highest_Q != '')
{
	$be = $be +1;
}
if($Postal_Code != '')
{
	$be = $be +1;
}
if($Drivers != '')
{
	$be = $be +1;
}

if($Own_Car != '')
{
	$be = $be +1;
}
if($dog != '')
{
	$be = $be +1;
}



$bql = "SELECT * FROM $tb2_name WHERE Email='$company' ";
$result1 = $conn->query($bql);

    // output data of each row
	$result1 = mysqli_query($conn, $bql);
    $row1 = mysqli_fetch_array($result1, MYSQLI_BOTH);
    $Email = $row["Email"];
    $Town = $row["Town"];
	$Country4 = $row["Country"];
	$Subject1 = $row["Subject1"];
	$Score1= $row["Score1"];
$Subject2 = $row["Subject2"];
	$Score2= $row["Score2"];
$Subject3 = $row["Subject3"];
	$Score3= $row["Score3"];
$Subject4 = $row["Subject4"];
	$Score4= $row["Score4"];
$Subject5 = $row["Subject5"];
	$Score5= $row["Score5"];
$Subject6 = $row["Subject6"];
	$Score6= $row["Score6"];
	
    if($Town != '')
{
	$be = $be +1;
}
if($Country4 != '')
{
	$be = $be +1;
}
if($Subject1 != '')
{
	$be = $be +1;
}
if($Subject2 != '')
{
	$be = $be +1;
}
if($Subject3 != '')
{
	$be = $be +1;
}
if($Subject4 != '')
{
	$be = $be +1;
}
if($Subject5 != '')
{
	$be = $be +1;
}
if($Subject6 != '')
{
	$be = $be +1;
}




$mef = $be ;

?>