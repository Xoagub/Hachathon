 
 <?php
	  
	  include('user_display.php');
	
	  ?>




<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                <a href="http://www.Motlee-systems.com/Recruitment/" class="simple-text logo-normal">
                  back to website 
                </a>
				 <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$data2 = ".jpg";
$result = $company . $data2;

if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div>
            </div>
            <div class="sidebar-wrapper">
    <ul class="nav">  		 <li class="active+">
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                    <li >
                        <a href="dashboard.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>History</p>
                        </a>
                    </li>
                 <li>
                        <a href="apply.php">
                             <i class="now-ui-icons gestures_tap-01"></i><p>Vacancies</p>     </a></li>
                
                   <li>
                        <a href="../../../platforms.php" target="_blank" >
                               <i class="now-ui-icons location_world"></i> <p>Explore</p>     </a></li> 
					<li class="">
                        <a  href="../../../courses.php" target="_blank">
                               <i class="now-ui-icons education_hat"></i>
                            <p>E-Learning</p>
                        </a>
                    </li>
                   
                    <li>
                        <a href="log_Off.php">
                              <i class="now-ui-icons sport_user-run"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid" >
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler" style="background-color: #0033FF">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                     
                    </div>
                   
                  
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">My Profile</h5>
                            </div>
                            <div class="card-body">

							<?php
$company = $_COOKIE["user"];
	
$link_address = 'cv.php';
$target_dir = "cv/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$newFileName = $target_dir .$company.'.'. pathinfo($_FILES["fileToUpload"]["name"] ,PATHINFO_EXTENSION); //get the file extension and append it to the new 
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image


// Check file size
if ($_FILES["fileToUpload"]["size"] > 50000000) {
    echo "Sorry, your file is too large.";
	echo "<a href='$link_address'>Upload</a>";
    $uploadOk = 0;
}

if($imageFileType != "pdf"  ) {
    echo "Sorry, only pdf files are allowed.";
    $uploadOk = 0;
}								
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";

// if everything is ok, try to upload file
} else {
    	if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],  $newFileName)) {
       echo "Your Cv was upload";
    } else {
        echo "Your CV was not uploaded";
    }
}


?>



 </div>
                    </div>
        
        </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
