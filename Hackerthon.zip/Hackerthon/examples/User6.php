 
 <?php
 

$user = $_COOKIE["user4"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 

$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$English = $row["English"];
		$Permit = $row["Permit"];
    
     
 if($Drivers = 1)
 {
 $dr = "A";
 }
 elseif($Drivers = 2)
 {
 $dr = "B";
 } 
  elseif($Drivers = 3)
 {
 $dr = "BE";
 }
  elseif($Drivers = 4)
 {
 $dr = "C1";
 }
  elseif($Drivers = 5)
 {
 $dr = "C";
 }
  elseif($Drivers = 6)
 {
 $dr = "CE";
 }
 else
 {
 
 $dr = "None";
 }
 
 if($English = 1)
 {
 $en = "Poor";
 }
 elseif($English = 2) 
 {
 $en = "Fair";
 }
 elseif($English = 3)
 {
 $en = "Good";
 }
 else
 {
 $en = "none";
 }
//Create a DateTime object using the user's date of birth.
$dob = new DateTime($Age);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age1 = $difference->y;
	

	
	  ?>



<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
            <div class="logo">
                
                <div align="center"><img src="M.png"></div>
				 <?php

$company =  $user; 
$Surname1 = $_COOKIE["Surname"];

	
$data2 = ".jpg";
$result = $company . $data2;

$data3 = ".pdf";
$result1 = $company . $data3;




$me = $_COOKIE["company"];

?><div style="color: white"><?php echo  " $me $Surname1" ; ?></div>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                           
                 
             
                    <li>
                        <a href="User6.php">
                         
                           <p>Profile</p>
                        </a>
                    </li>
                   
                     <li>
                        <a href="Education5.php">
                          
                            <p>High school</p>
                        </a>
                    </li>
                     <li>
                        <a href="Tertiary5.php">
                           
                            <p>Tertiary Education</p>
                        </a>
                    </li>
                     <li>
                        <a href="Employment5.php">
                           
                            <p>Employment History </p>
                        </a>
                    </li>
                     <li>
                        <a href="reference5.php">
                      
                            <p>References</p>     </a><li> 
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
             <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center"><?php echo $user ;?> Profile </h5>
                            </div>
                            <div class="card-body">
                                <form >
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Name: </label>
                                               <?php echo $Name ; ?>
                                            </div>
                                        </div>
										</div>
										<div class="row">
                                        <div class="col-md-12">
                                         <div class="form-group">
                                                <label>Surname: </label>
                                                <?php echo $Surname ; ?>
                                            </div>
                                        </div>
										</div>
										<div class="row">
                                        <div class="col-md-12">
                                          <div class="form-group">
                                                <label for="exampleInputEmail1">Email address:</label>
                                                <?php echo $Email ; ?>
                                            </div>
                                        </div>
										</div>
										
                                  
									
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Cellphone:</label>
                                               <?php echo $Cellphone ;?>
                                            </div>
                                        </div>
										</div>
                                       <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Gender:</label>
                                               <?php echo $Gender;?>
                                                </div>
                                            </div>
                                        </div>
										
										<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Drivers:</label>
                                                <?php echo $dr;?>
                                            </div>
                                        </div>
										</div>
										<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Own Car:</label>
                                                <?php echo $Own_Car;?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Date Of Birth:</label>
                                                <?php echo $Age ; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address:</label>
                                                <?php echo $Address ; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>City:</label>
                                               <?php echo $City ; ?>
                                            </div>
                                        </div>
										</div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Country:</label>
                                               <?php echo $Country ; ?>
                                            </div>
                                        </div>
										</div>
                                        <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Postal Code:</label>
                                                <?php echo $Postal_Code ; ?>
                                            </div>
                                        </div>
                                    </div>
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>English:</label>
                                                 <?php echo $en ;?>
                                            </div>
                                        </div>
                                    </div>
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Work Permit:</label>
												<?php echo $Permit ;?> 
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Qualifications Obtained:</label>
                                                <?php echo $Highest_Q; ?>  
                                            </div>
                                        </div>
                                    </div>
                                    
					 <div class="row">
                                        <div class="col-md-5 pr-1">
                                            <div class="form-group">
                                                
                                            </div>
                                        </div>
                              		</div>
                                </form>
                            </div>
                        </div>
                    </div>
        <div class="col-md-4">
            <div class="card card-user">
              <div class="image">
                <img src="../assets/img/bg5.jpg" alt="...">
              </div>
              <div class="card-body">
                <div class="author">
                 
				  <a href="#">
                    <img class="avatar border-gray" src="../examples/uploads/<?php echo $result; ?>" alt="...">
                    <h6 class="title" style="color:#0066FF"><?php echo  $Name ; ?><?php echo $Surname ; ?></h6>
                  </a>
                  <p class="description">
                    <?php echo $age1 ; ?><br>
					
					<div align="center">
				  <a href="cv/<?php echo $result1 ; ?>" style="color:#0066FF" target="_blank" class="simple-text logo-normal"> View CV
				   <p></p>
				  <p></p>
               
              </div>
                  </p>
                </div>
                </div>
				 
              <hr>
              
            </div>
          </div>
        </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
