 
 <?php

$user54 = $_GET['boom1']; 
$user55 = $_GET['boom']; 


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="User_Profile"; // Table name 
$tbl8_name="gig"; // Table name 
$db_name="Hack"; // Table name 
$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query
 $domain = "";

$sql = "SELECT * FROM $tbll_name WHERE Email='$user54' AND Domain = '$domain' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
    $Name = $row["Name"];
	$Surname = $row["Surname"];
	$Cellphone = $row["Cellphone"];
	$Gender = $row["Gender"];
	$Age = $row["Age"];
	$Address = $row["Address"];
	$City = $row["City"];
	$Country3 = $row["Country"];
	$Highest_Q = $row["Highest_Q"];
	$About = $row["About"];
		$Postal_Code = $row["Postal_Code"];
		
			$Drivers = $row["Drivers"];
	$Own_Car = $row["Own_Car"];
	$dog = $row["English"];
		$Permit = $row["Permit"];
$sp = $row["Specialty"];
$interest = $row["interest"];

	  
 

	

$tbl1_name="gig";


$clear = "clear";


$active ="active";

$cow = "Paid";

$query = "SELECT * FROM $tbl8_name WHERE ID = '".$user55."'   ORDER BY ID DESC
 "; //Write a query
	  
 

//Create a DateTime object using the user's date of birth.
$dob = new DateTime($Age);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age1 = $difference->y;
	
	  ?>



<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
		<link rel="stylesheet" type="text/css" href="loading-bar.css"/>
<script type="text/javascript" src="loading-bar.js"></script>
	
	<script>
function myFunction() {
  alert("Please complete your profile to have a better chance of being selected");
}
</script>
	
<script type="text/javascript">
$(document).ready(function(){
    var maxField = 5; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div> <input type="text"  style="color:black" style="color: black" name="field_name[]" value="Company" class="form-control"/><a href="javascript:void(0);" class="remove_button" style="color:#0066FF">Delete</a></div>'; 
	
	 var fieldHTML1 = '<div> <input type="text"  style="color:black" style="color: black" name="field_name1[]" value="Position" class="form-control"/><a href="javascript:void(0);" class="remove_button" style="color:#0066FF">Delete</a></div>';//New input field html 
	  var fieldHTML2 = '<div> <input type="text"  style="color:black" style="color: black" name="field_name2[]" value="Years Employed" class="form-control"/><a href="javascript:void(0);" class="remove_button" style="color:#0066FF">Delete</a></div>';//New 
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML);
			$(wrapper).append(fieldHTML1); //Add field html
			$(wrapper).append(fieldHTML2); //Add field html

        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove();
		 $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>
</head>

<body class=""  onLoad="demo.showNotification('top','right')">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    --> <?php

$company = $_COOKIE["user"];
$Surname1 = $_COOKIE["Surname"];

	
$data2 = ".jpg";
$result = $company . $data2;

$data3 = ".pdf";
$result1 = $company . $data3;
	   
	  

				  $data4 = ".mp4";
				  
$result5 = $company . $data4;



$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Apply"; // Table name 
$tbl2_name="gig"; // Table name
$tb3_name="video"; // Table name
	$db_name="motleesy_namtax"; // Table name    
	   $tb4_name="puictures"; // Table name
$db_name="motleesy_namtax"; // Table name 
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB");


// username and password sent from form 
 
	$pql="SELECT * FROM $tb3_name WHERE user = '".$company."' ORDER BY id DESC limit 1 ";


    // output data of each row
	$result87 = mysqli_query($link, $pql);
    $row = mysqli_fetch_array($result87, MYSQLI_BOTH);

	
	$me44 = $row["name"];	
	   
	   $me54 = ".";
	  $ve = $me54 . $me44 ;
	   
	 
	 $cat = $company . $ve ;
	   
	   
	   
	   $pqr="SELECT * FROM $tb4_name WHERE user = '".$company."' ORDER BY id DESC limit 1 ";


    // output data of each row
	$result89 = mysqli_query($link, $pqr);
    $row4 = mysqli_fetch_array($result89, MYSQLI_BOTH);

	
	$me444 = $row4["name"];	
	   
	   $me544 = ".";
	  $ve4 = $me544 . $me444 ;
	   
	 
	 $cat4 = $company . $ve4 ;
	   
	   $me = $_COOKIE["company"];
	   
	   if($me444 != '')
		   
	   {
		   $be3 = "14";
		   
	   }
	if($me44 != "")
	{
		$bem = "20";
		
	}
	   
$file = "cv/$result1";

if (file_exists($file)) {
	
$vas = "30";
	

    
	} else {
    
}
	   	$mef1 =(($mef +$be3+$vas+$bem)/87)*100 ;
?>
            <div class="logo">
                
                        <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
			  <h7 class="title">
			
				 
			<div style="color: white"><?php echo  " $me $Surname1" ; ?></div>
        </div>    </div>
            <div class="sidebar-wrapper">
                <ul class="nav">  		 <li class="active">
                        <a href="user.php">
                            <i class="now-ui-icons users_single-02"></i>
                           <p>Profile</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="dashboard.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Ratings</p>
                        </a>
                    </li>
					
					 <li>
                        <a href="apply2.php">
                            <i class="now-ui-icons education_hat"></i> <p>View Gigs</p>     </a></li>
                
                
                   <li>
                        <a href="apply.php">
                            <i class="now-ui-icons education_hat"></i> <p>Post Gig</p>     </a></li>
                        
                           <li class="">
                        <a href="service.php">
                         <i class="now-ui-icons arrows-1_refresh-69"></i>
                            <p>Service Provider</p>
                        </a>
                    </li>
                    <li>
                        <a href="log_Off.php">
                              <i class="now-ui-icons sport_user-run"></i>
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
                       <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid" >
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler" style="background-color: #0033FF">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                     
                    </div>
                   
                  
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="panel-header panel-header-sm" style="background:#FFFFFF" >
			<div align="center" ><div
  data-preset="bubble"
  class="ldBar label-center"
  data-value="<?php echo (int)$mef1 ; ?> "
></div></div>
			
            </div>
            <div class="content">
                <div class="row">
					   <div class="col-md-10">
            <div class="card card-user">
              <div class="image">
                <img src="../assets/img/bg5.jpg" alt="...">
              </div>
              <div class="card-body">
                <div class="author">
                  <a href="#">
					  <?php
					  $space = "";
 ?>
					  <!--
                    <video class="avatar border-gray" width="15" height="50" controls>
  <source src="../examples/videos/<?php echo $cat; ?>" type="video/mp4">
 
</video> --> <img class="avatar border-gray" src="../examples/uploads/<?php echo $cat4; ?>"  alt="...">

                    <h6 class="title" style="color:#0066FF"> <?php echo $me ;?><?php echo $space; ?><?php echo $Surname1 ; ?><br></h6><br>

                  </a>
                  <p class="description">
				      </br> Industry <br>
                          <?php echo $interest ;?> 
						  </br>
                                                <?php echo $age1 ; ?>
				 </br>
                                                Contact Number <?php echo $Cellphone ; ?>
                  </p>
                </div>
				<div align="center">
                <a href="picture.php" class="simple-text logo-normal" style="color:#0066FF">
                  Change Picture </a>
				  <p></p>
				  <p></p>
			
					<p></p>
				  <p></p>
                </a>
					<?php 
					
					if($me444 !=="" )
					
					{
					?>
					<video height="150" width="200"  controls>
  <source src="../examples/videos/<?php echo $cat  ;  ?> " type="video/mp4" >
 <?php } ?>
</video><br>
				 <a href="Video.php" class="simple-text logo-normal" style="color:#0066FF">
                 Take/View Video Interview 
                </a>
					
					
				</div>
              </div>
              <hr>
              
            </div>
	
	<?php $data = mysqli_query($conn, $query);  //Execute the query
$num = mysqli_num_fields($conn, $query); 
	while($fetch_options = mysqli_fetch_array($data)) { ?>	
	
          </div><img src="view.png" width="70" height="70"> <strong> Gig Name : <?php echo $fetch_options['Name']; ?></strong>    &nbsp; &nbsp; &nbsp; &nbsp; <img src="success.png" width="70" height="70"> <strong> Description : <?php echo  $fetch_options['Description']; ?></strong> <br><br>
<img src="total.png" width="70" height="70"><strong>Wanted Date : <?php echo $fetch_options['wanted']; ?>  &nbsp; &nbsp; &nbsp; &nbsp; <img src="success.png" width="70" height="70"> <strong> Price : <?php echo  $fetch_options['Price']; ?></strong></strong><?php }?>
							<br><br>
                  									<div class="field_wrapper">
    <div>
        <input type="hidden" name="field_name[]" value="" class="form-control"/>
		  <input type="hidden" name="field_name1[]" value="" class="form-control" />
		  <input type="hidden" name="field_name2[]" value="" class="form-control" />
        <a href="javascript:void(0);" class="add_button" title="Add field" style="color:#0066FF">Make Bid </a>
    </div>
</div>
                 
     
        </div>
               
  
                
           
            
            </div>
            
             
            
                    
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
	

</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
