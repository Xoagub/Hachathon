<?php
	
$user = $_COOKIE["user"];
$company = $_COOKIE["company"];



$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Past_Work"; // Table name 
			


// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query

$ty3= "Botswana";
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' AND Domain ='".$ty3."' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	$Company1 = $row["Company1"];
    $Person1 = $row["Person1"];
	$Contact1 = $row["Contact1"];
	
	$Company2 = $row["Company2"];
    $Person2 = $row["Person2"];
	$Contact2 = $row["Contact2"];
	
	$Company3 = $row["Company3"];
    $Person3 = $row["Person3"];
	$Contact3 = $row["Contact3"];
	
	$Company4 = $row["Company4"];
    $Person4 = $row["Person4"];
	$Contact4 = $row["Contact4"];
	
	$Company5 = $row["Company5"];
    $Person5 = $row["Person5"];
	$Contact5 = $row["Contact5"];
	
	
    
	
?>