<?php
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
  $secret_key = '4C4991AFE3C5473BF6DA0A3DADA4B0FDABBD0FC5C2830942E25C409F19A79C55';
    $secret_iv = 'F857968FC3AC148380D4E6A00612F29D';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}



$user = $_COOKIE["user"];
$company = $_COOKIE["company"];

$user= stripslashes($user);
$company=  stripslashes($company) ;

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="High_School"; // Table name 
$db_name="motleesy_namtax"; // Table name 
$Final="yes";

// Connect to server and select databse.
$conn = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");

// Construct our join query
// sending query

$domain = "Botswana";
 
$sql = "SELECT * FROM $tbll_name WHERE Email='$user' AND Domain ='$domain' ";
$result = $conn->query($sql);

    // output data of each row
	$result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_BOTH);
    $Email = $row["Email"];
	$High_School = $row["High_School"];
    $Grade_Twelve = $row["Grade_Twelve"];
	$Town = $row["Town"];
	$Country1 = $row["Country"];
	$Subject1 = $row["Subject1"];
	$Score1 = $row["Score1"];
	$Subject2 = $row["Subject2"];
	$Score2 = $row["Score2"];
	$Subject3 = $row["Subject3"];
	$Score3 = $row["Score3"];
	$Subject4 = $row["Subject4"];
	$Score4 = $row["Score4"];
	
	$Subject5 = $row["Subject5"];
    $Score5 = $row["Score5"];
	$Subject6 = $row["Subject6"];
	$Score6 = $row["Score6"];
	$Subject7 = $row["Subject7"];
	$Score7 = $row["Score7"];

	$encrypted_txt17 = encrypt_decrypt('encrypt',  $Email);
		$encrypted_txt21 = encrypt_decrypt('decrypt',  $High_scool);
		$encrypted_txt22 = encrypt_decrypt('decrypt', $Town);
		$encrypted_txt23 = encrypt_decrypt('decrypt', $Country5);
		$encrypted_txt24 = encrypt_decrypt('decrypt', $Subject1);
		$encrypted_txt25 = encrypt_decrypt('decrypt', $Score1);
		$encrypted_txt26 = encrypt_decrypt('decrypt', $Subject2);
		$encrypted_txt27 = encrypt_decrypt('decrypt', $Score2);
		$encrypted_txt28 = encrypt_decrypt('decrypt', $Subject3);
		$encrypted_txt29 = encrypt_decrypt('decrypt', $Score3);
		$encrypted_txt30 = encrypt_decrypt('decrypt', $Subject4);
		
		$encrypted_txt31 = encrypt_decrypt('decrypt', $Score4);
		$encrypted_txt32 = encrypt_decrypt('decrypt', $Subject6 );
		$encrypted_txt33 = encrypt_decrypt('decrypt', $Score6);
		$encrypted_txt34 = encrypt_decrypt('decrypt', $Subject7);
		$encrypted_txt35 = encrypt_decrypt('decrypt', $Score7);

	
    
	
?>