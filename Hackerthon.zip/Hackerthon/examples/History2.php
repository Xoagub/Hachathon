<?php

$be = $_COOKIE["cat"];
$be1 = $_COOKIE["cat1"];



?>

<!DOCTYPE html>
<html lang="en">

<head><script async src="https://www.googletagmanager.com/gtag/js?id=UA-137784379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137784379-1');
</script>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"> <link rel="shortcut icon" type="image/x-icon" href="banner.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Motlee Systems</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/demo/demo.css" rel="stylesheet" />
	
	<script>
function myFunction() {
  alert("Once You Select Candidates for Interview and save , it can not be Undone .");
}
</script>
</head>

<body  class="" onLoad="myFunction()">
    <div class="wrapper ">
   <div class="sidebar" data-color="blue">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
             <div class="logo">
                
                       <div align="center"><img src="M.png"></div>
                    </br>
                </a>
				<div align="center">
				  <h7 class="title"> 
				 <?php

$company3 = $_COOKIE["user"];
$Surname1 = $_COOKIE["company"];

	
$data2 = ".jpg";
$result = $company . $data2;

$result6 = glob("../examples/company_upload/$company3.*");

$data3 = ".pdf";
$result1 = $company . $data3;

if(!isset($_COOKIE["user"]))  {

    header("www.motlee-systems.com/Recruitment/");
} 


$me = $_COOKIE["company"];

echo  " $me " ; $company = $_COOKIE["user"];

// get supervisor email
$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 

$tbl1_name="Apply";
// Connect to server and select databse.
$link = mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($link,"$db_name")or die("cannot select DB"); 





$active ="active";


$query = "SELECT * FROM $tbl1_name  WHERE Application_ID = '$be' AND Points >= '$be1' ORDER BY Points DESC; 
 "; //Write a query
$data = mysqli_query($link, $query);  //Execute the query
$num = mysqli_num_fields($link, $query);

?></h7>
</div>
            </div>
            <div class="sidebar-wrapper">
                          <ul class="nav">
                    <li>  <a href="dashboardc.php">
                       
                            <p>Dashboard</p>
                        </a>
                    </li>
                
                 
             
                    <li>
                        <a href="company_profile.php">
                        
                            <p>Company Profile</p>
                        </a>
                    </li>
                     <li>
                        <a href="Load_Vacancy.php">
             
                            <p>Load Vacancy</p>
                        </a>
                    </li> <li>
                        <a href="prescreaning.php">
                            
                            <p>Prescreening question </p>
                        </a>
                    </li>
                     <li class="active">  <a href="History.php"> <p>Pre-Screening </p>     </a><li>
							  <li>
                        <a href="Reports.php">
                            
                            <p>Reports</p>
                        </a>
                    </li>
							
							
							  <li>
                        <a href="log_Off.php">
                            
                            <p>Sign Out</p>
                        </a>
                    </li>
					
	
                 </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
           
            <!-- End Navbar -->
           <div class="panel-header panel-header-sm" style="background:#FFFFFF">
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title" align="center">Pre Screening Results</h5>
                            </div>
                            <div class="card-body">
                                <form action="#" method="post" name="form">
                                                                       
                                    <div class="row">
                                        <div class="col-md-6 pr-1">
                                           
                                                <div class="form-group">
                                                <table class="table">
                                        <thead class=" text-primary">
                                            <th align="center">
                                                View Candidate and CV
                                            </th>
                                            <th>
                                                Position
                                            </th>
                                            <th align="center">
                                                Points
                                            </th>
											<th align="center">
                                               Status
                                            </th>
											 <th class align="center">
                                               Select for Interview
                                            </th>
											
                                        </thead>
		     <?php
while($fetch_options = mysqli_fetch_array($data)) { //Loop all the options retrieved from the query

$cat = $fetch_options['Interview'];
$fe = "Interview";
if($cat === $fe)
{
$de = "checked";
}
else
{
$de = "";
}
?>



		    <tbody>
			<tr >
			    
			  	   
			   <td><a style="color:#0066FF" href="User5.php?var=<?php echo $fetch_options['User']; ?>" target="_blank"> <?php echo $fetch_options['User']; ?></a></td>
			    <td><?php echo $fetch_options['Position'];  ?></td>
			    <td><?php echo $fetch_options['Points'];  ?>%</td>
				<td><?php echo $fetch_options['Interview'];  ?></td>
			   <td> <input type="checkbox"  class="form-control" name="check_list[]" value="<?php echo $fetch_options['User']; ?> " <?php echo $de ; ?> ></td>
			   
			    			<?php
}
?>
			</tr>

		    </tbody>
		</table>
                                            </div>
										</div>
									</div>
                                             						
                                            <div class="row">
                                                <div class="col-md-12">
                                            <div class="form-group">
                                                  
                                 						
                                                  <input type="submit" class="form-control" value="save" name="submit" style="background-color: #0066FF"  >
                                 														 
												 
                                            </div>
                                        </div>
                                      								 
												 
                                            </div>
                                        </div>
                                       
                                </form>
								
								<?php
								

if(isset($_POST['submit'])){//to run PHP script on submit


if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){

$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password $db_name="motleesy_namtax"; // Database name 
$tbll_name="Apply"; // Table name 

$cat = "Interview";

$fql=("UPDATE $tbll_name SET Interview = '".$cat."' WHERE User = '".$selected."' AND Application_ID = '".$be."'  ");

if (!mysqli_query($link,$fql))
  {  



  }
  

}
$je = "Unsuccesfull" ;

$dw = "Interview";
$yql=("UPDATE $tbll_name SET Interview = '".$je."' WHERE Interview != '".$dw."' AND Application_ID = '".$be."'  ");

if (!mysqli_query($link,$yql))
  {  



  }

}
 header("location: History2.php");
}



?>



                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul>
                            <li>
                                <a href="https://www.Motlee-Systems.com">
                                    Motlee Systems
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>, Motlee Systems.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1"></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/demo/demo.js"></script>

</html>
