<?php 


$host="localhost"; // Host name 
$username="username"; // Mysql username 
$password="password"; // Mysql password 
$db_name="Hack"; // Database name 
$tb1_name="User_Profile"; // Table name 
$tb2_name="Company_Profile";
$tb3_name="User_password";
 // Table name


// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect"); 
mysqli_select_db($con,"$db_name")or die("cannot select DB");


?>